/****************************************************************************
 *

 *
 ****************************************************************************
 *
 * THE SOFTWARE IS PROVIDED ��AS IS��. BPS DISCLAIMS ALL WARRANTIES WHETHER EXPRESS, IMPLIED OR 
 * STATUTORY, INCLUDING, WITHOUT LIMITATION, THE IMPLIED WARRANTIES OF NONINFRINGEMENT, 
 * MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE.? IN NO EVENT SHALL BPS BE LIABLE FOR ANY 
 * DIRECT, INDIRECT, SPECIAL, PUNITIVE, EXEMPLARY, ENHANCED, INCIDENTAL OR CONSEQUENTIAL DAMAGES 
 * (INCLUDING LOSS OF PROFITS AND LOSS OF USE) RESULTING FROM, BASED UPON, ARISING OUT OF OR IN 
 * CONNECTION WITH THE SOFTWARE.
 *
 * Copyright BPSEMI. 2021. All rights reserved
 *
 ****************************************************************************/
 /****************************************************************************/
/***        Include files                                                 ***/
/****************************************************************************/
/* Standard includes */
#include "Global_Variable.h"
#include "hardware_config.h"
#include "lks32mc03x_Gpio.h"
#include "USER_APP.h"
#include "lks32MC03x_Flash.h"
#include "HeatControl.h"
#include "PowerCalculation.h"

void USER_APP_vTick1ms(void);
void USER_APP_vTick10ms(void);
void USER_GPIO_Init(void);
void USER_Init(void);
void zero_cheak(void);
struct appcmdkey AppCmdKey;
s32 powerfreqcmd[maxgear]={0,0,0};
stru_UserSys UserSys;
void MemoryRestore(void);
void EraseWriteFlash(void);
void Get_Power(void);
void vLoadForFlashing(void);
void SpecialGPIOInit(void);
extern void HeaterControl_1ms(void);
void FunStateCharge(void);
void USER_APP_vTick500ms(void);
void Shut_down(void);
void Alarm_light(void);

void Light_Col_Contr(u8 Light_Col,u8 onfoff_state);
/****************************************************************************/
/***        END OF FILE                                                   ***/
/****************************************************************************/


u8 TempGear = 0;
u8 TempOverFlag = 0;
u8 NTCSHORTErrorFlag = 0;
u8 NTCOPENErrorFlag = 0;
u8 TempOverFlagnoclean = 0;
u8 TempGearOld = 0;
u8 iTargetGear=0; 
u8 AutoTemp =0;
u8 TempGear_Last = 0;
u32 Memorymsg;
u8 TempGear_memory;
u32 remotor_memory;
u8 Memorymessag_eraseflg;
u16 blink_ON_CNT=0;
u16 blink_OFF_CNT=0;
u16 led_duty=0;
u16 led_on_CNT=0;
u16 led_off_CNT=0;
u8 color_old=0;
extern u8  BrakeFlag;

void USER_GPIO_Init(void)
{
	GPIO_InitTypeDef GPIO_InitStruct;
	GPIO_StructInit(&GPIO_InitStruct);

	LED1B_OFF();
	LED2Y_OFF();
	LED3R_OFF();
	/*P1.4 LED1  */
    GPIO_InitStruct.GPIO_Mode = GPIO_Mode_OUT;
    GPIO_InitStruct.GPIO_PuPd = GPIO_PuPd_UP;
    GPIO_InitStruct.GPIO_Pin =   LED2_PIN;
    GPIO_Init(LED2_PORT, &GPIO_InitStruct);
				
    /* P0.3 LED3  P0.1 LED2 */
    GPIO_InitStruct.GPIO_Mode = GPIO_Mode_OUT;
    GPIO_InitStruct.GPIO_PuPd = GPIO_PuPd_UP;
    GPIO_InitStruct.GPIO_Pin =  LED1_PIN | LED3_PIN;
    GPIO_Init(LED1_PORT, &GPIO_InitStruct);
	  GPIO_Init(LED3_PORT, &GPIO_InitStruct);
	LED1B_OFF();
	LED2Y_OFF();
	LED3R_OFF();
			
	/* P0.8 SW_TEMP P0.10 SW_SPEED */
    GPIO_InitStruct.GPIO_Mode = GPIO_Mode_IN;
    GPIO_InitStruct.GPIO_PuPd = GPIO_PuPd_NOPULL;
    GPIO_InitStruct.GPIO_Pin =  KEY_WindTemp_port_pin | KEY_WindSpeed_port_pin;
    GPIO_Init(KEY_WindTemp_port, &GPIO_InitStruct);
	
	/* P0.6 AC cheak*/
	GPIO_InitStruct.GPIO_Mode = GPIO_Mode_IN;
    GPIO_InitStruct.GPIO_PuPd = GPIO_PuPd_NOPULL;
    GPIO_InitStruct.GPIO_Pin =  ZERO_PIN ;
    GPIO_Init(ZERO_PORT, &GPIO_InitStruct);
	
	/* P0.4 HEATER CONTROL*/
	HEATER_CONTROL_OFF();   //�ϵ�Ĭ�Ϲرշ���˿
	GPIO_StructInit(&GPIO_InitStruct);
	GPIO_InitStruct.GPIO_Mode = GPIO_Mode_OUT;
	GPIO_InitStruct.GPIO_Pin = HEATER_CONTROL_PIN ;
	GPIO_Init(HEATER_CONTROL_PORT, &GPIO_InitStruct);
	HEATER_CONTROL_OFF();   //�ϵ�Ĭ�Ϲرշ���˿
	
}

void USER_Init(void)
{
	UserSys.ucMotorDir = CW;
	
	UserSys.ucUserFunState = USERFUN_STATE_WAIT;
	
	UserSys.RunTime = 0;
	stru_FaultValue.NTC_Lose_AlA_CNT=0;
   //DataUpdateRT();
//	powerfreqcmd[0] = App2CoreFreqTrans(User2AppFreqTrans(Gear_Speed_01)); //
//	
//	powerfreqcmd[1] = App2CoreFreqTrans(User2AppFreqTrans(Gear_Speed_02));
//	
//	powerfreqcmd[2] = App2CoreFreqTrans(User2AppFreqTrans(Gear_Speed_03));
		
	remotor_memory = *((u32 *) Rmt_NVM_Sector_StartAddr);
	//Read_Flash(Rmt_NVM_Sector_StartAddr, (u32 *)&remotor_memory, 1, NVR_TYPE);
//	remotor_memory =      NVR_UserRoomRead((UINT32)200<<2);   //light_fan
#ifdef  MemoryMode
    MemoryRestore();
#endif	
}


/* adc 22300Ϊ���ڷ���  adc Ϊ14800Ϊ�����¶ȣ���ʱ���Ϊ0���㰴����190���㰴�¶�140*/
u8 key1cnt=0;
u8 key2cnt=0;
u8 key3cnt=0;
u8 u8key1cnt=0;
u8 u8key2cnt=0;
u8 u8key3cnt=0;


u8 speed2=0;
u8 temp2=0;
u16 AutoTempLED2S;
u8	KEY_WindSpeedCnt1	=	0;
u8	KEY_WindSpeedCnt2	=	0;
u8	KEY_WindSpeedAcState = 0;
u8	WindSpeedKeyStateLast	=	0;
u8	WindSpeedKeyState	=	0	;
u16 KEY_WindTempONCnt=0;					//���°���ʱ��
u16 KEY_WindTempOFFCnt=0;					//�����ɿ�ʱ��
//void RemtCmdAns(void)

void LED_1MS_CYCLE(void);
extern void LED_ONOFF_SET(u8 ShineTimes, u8 ShineMode);

void Key_Refresh(void)
{
	//**********************���ټ��******************************//
	WindSpeedKeyState = KEY_WindSpeed();  //��ȡ��λ�źŵ�ƽ

	if(WindSpeedKeyState == 1)
	{
		if(KEY_WindSpeedCnt1 < CROSSZERO_CNT2)
		{
			KEY_WindSpeedCnt1++;
		}		
	}
	else if(WindSpeedKeyState == 0)
	{
		if(KEY_WindSpeedCnt1>0)
		{
			if((KEY_WindSpeedCnt1< CROSSZERO_CNT1)&&(KEY_WindSpeedCnt2 < CROSSZERO_CNT1))
			{
				KEY_WindSpeedAcState=AC_ZERO_ON;
			}
			KEY_WindSpeedCnt1=0;
			KEY_WindSpeedCnt2=0;
		}
		
		if(KEY_WindSpeedCnt2 < CROSSZERO_CNT2)
		{
			KEY_WindSpeedCnt2++;
		}				
	}
	
	if(KEY_WindSpeedCnt2 > CROSSZERO_CNT1)
	{
		KEY_WindSpeedAcState=AC_ZERO_OFF;
	}

	if(KEY_WindSpeedCnt1 > CROSSZERO_CNT1)
	{
		KEY_WindSpeedAcState=AC_ZERO_OFF;
	}
	
	if(KEY_WindSpeedAcState == AC_ZERO_OFF)
	{
		iTargetGear=0;
		u8PwmFrqLo2Hi = 0;
	}

	if(KEY_WindSpeedAcState == AC_ZERO_ON)
	{
		iTargetGear=1;
		u8PwmFrqLo2Hi = 1;
	}
    WindSpeedKeyStateLast = WindSpeedKeyState;   //��¼��λ�źŵ�ƽ
	//**********************���ټ��******************************//
	//**********************���¼��******************************//		
	
	if(!FRSControl.CrossDownAcState){
		
	if(!KEY_WindTemp())
	{
		if(KEY_WindTempONCnt<10000)
		{
			KEY_WindTempONCnt++;
		}
		else
		{
			KEY_WindTempONCnt=10000;
		}
		if(KEY_WindTempONCnt>10)KEY_WindTempOFFCnt=0;
		
		if(KEY_WindTempONCnt>3000)	//��������
		{
			AppCmdKey.sts = 1;
			AppCmdKey.cmd_exe = KEY_WindTemp_L;
		}
		
	}
	else 
	{
		if(KEY_WindTempOFFCnt<100)
		{
			KEY_WindTempOFFCnt++;
		}
		if((KEY_WindTempOFFCnt>50)&&(KEY_WindTempONCnt>50)&&(KEY_WindTempONCnt<3000))			//�̰�����
		{
			AppCmdKey.sts = 1;
			AppCmdKey.cmd_exe = KEY_WindTemp_S;
			KEY_WindTempONCnt = 0;
		}
		else if((KEY_WindTempOFFCnt>50)&&(KEY_WindTempONCnt>3000))			//��������
		{
			AppCmdKey.sts = 1;
			AppCmdKey.cmd_exe = KEY_WindTemp_L;
			KEY_WindTempONCnt = 0;
		}

		else if((KEY_WindTempOFFCnt>50)&&(KEY_WindTempONCnt<50))
		{
			KEY_WindTempONCnt = 0;
		}
		
	}
	}
	

	
	//**********************���¼��******************************//	
}

void RemtCmdAns(void)
{

	if(!FRSControl.CrossDownAcState)
	{
			if(AppCmdKey.sts)
			{
					AppCmdKey.sts = 0;
					switch  (AppCmdKey.cmd_exe)
					{
							case  KEY_WindTemp_S:
							
								if(AutoTemp==0)
								{          
									 TempGear++;
									 if(TempGear>2)
										{
											AutoTemp=1;
											
										}
										if (TempGear>3){
										TempGear = 0;
										}
								 }
								else
								{
									AutoTemp=0;
									TempGear=0;
								}
										
								 break;
								case KEY_WindTemp_L:
									

								if(AutoTemp==0)
									{ 
											TempGear++;
									
										if(TempGear>3)
										{
											TempGear=0;
										}				
									}
										else
									 {
										AutoTemp=0;
									 TempGear=0;
										}
								 break;		
							
						
								 default:

									break;		
							}
					}
	}
	
//TempGear=2;


	
	
}
extern u8 NTCorStaller;
void LED_Display(void)
{
	//*********************LED********************//
	if((!FRSControl.CrossDownAcState)&&(stru_Faults.B.TempOverError == 0)&&(TempOverFlagnoclean==0)&&(stru_Faults.R==0)&&(NTCOPENErrorFlag==0)&&(NTCSHORTErrorFlag==0))
	{
		if(!AutoTemp)                        //�������� ��-����-����
		{
			if(TempGear==0)
			{
//					LED1B_ON();//LED1 ��
//					LED2Y_OFF();//LED2 ��
//					LED3R_OFF();//LED3  ��
			}
			else	if(TempGear==1)
			{
					LED1B_OFF();
					LED2Y_ON();
					LED3R_OFF();
			}
			else	if(TempGear==2)
			{
					LED1B_OFF();
					LED2Y_OFF();
					LED3R_ON();
			}
			else
			{
					LED1B_OFF();
					LED2Y_OFF();
					LED3R_OFF();
			}
		
		}
//		 if(AutoTemp==1)                 // //�������� ����ѭ��  �������ж�������  PWMLED4 ��˸���ڴ˴��� ���ε�PWMLED4����
//		{
//			AutoTempLED2S++;
//			if(AutoTempLED2S==12000)
//				AutoTempLED2S=0;
//			if(AutoTempLED2S<6000)
//			{
//				TempGear=0;
//			}
//			else
//			{
//				TempGear=2;
//			}
//		}
//		else 
//		{
//			LED1B_OFF();
//			LED2Y_OFF();
//			LED3R_OFF();
//		}
	}
	else if((!FRSControl.CrossDownAcState)&&(stru_Faults.R!=0))  // ���ϵ���
	{
				if(stru_Faults.B.VoltOverError == 1)
				{
					LED1B_OFF();
        	LED2Y_OFF();
          LED3R_OFF();					
				  LED_flashing_alarm(3,Red,400);	           //60*1ms �� 60ms��  400ms��ʱ 			
				}
				else if(stru_Faults.B.VoltUnderError==1)
				{
					LED1B_OFF();
        	LED2Y_OFF();
          LED3R_OFF();
				  LED_flashing_alarm(1,Red,400);	
				}	
				else if((stru_Faults.B.TempOverError == 1)||(NTCorStaller==1)||(TempOverFlag ==1))
					{							
					LED1B_OFF();
        	LED2Y_OFF();
          LED3R_OFF();					
				  LED_flashing_alarm(10,Red,240);				
					}
				else if((TempOverFlag==1)||(TempOverFlagnoclean==1))
					{
				  LED1B_OFF();
        	LED2Y_OFF();
          LED3R_OFF();
					LED_flashing_alarm(11,Red,240);					
					}	
				else if((stru_Faults.B.NTCSHORTError ==1)||(NTCSHORTErrorFlag==1))//�¶ȹ��ϱ�־λ��1==1)
					{
				  LED1B_OFF();
        	LED2Y_OFF();
          LED3R_OFF();
					LED_flashing_alarm(8,Red,400);					
					}	
				else if((stru_Faults.B.NTCOPENError == 1)||(NTCOPENErrorFlag==1))
					{
				  LED1B_OFF();
        	LED2Y_OFF();
          LED3R_OFF();
					LED_flashing_alarm(9,Red,400);					
					}
				else if(stru_Faults.B.PhaseLossError==1)
							{						 
					    LED1B_OFF();
        	    LED2Y_OFF();
              LED3R_OFF();					
				      LED_flashing_alarm(6,Red,400);				
							}	
					else if(stru_Faults.B.StartError==1)
							{
							 
					    LED1B_OFF();
        	    LED2Y_OFF();
              LED3R_OFF();					
				      LED_flashing_alarm(5,Red,400);	
							
							}
					else		if(stru_Faults.B.HardCurretError == 1)
							{						 
					    LED1B_OFF();
        	    LED2Y_OFF();
              LED3R_OFF();					
				      LED_flashing_alarm(4,Red,400);				
							}
					else	if(stru_Faults.B.SoftCurretError==1)
							{						 
					    LED1B_OFF();
        	    LED2Y_OFF();
              LED3R_OFF();					
				      LED_flashing_alarm(2,Red,400);				
							}
	
	}
	else if(FRSControl.CrossDownAcState) //  �ϵ����
	{		
					LED1B_OFF();
					LED2Y_OFF();
					LED3R_OFF();
	}
	
	
}
u8  LED1_EN = 0, LED2_EN = 0, LED3_EN = 0, LED4_EN = 0, LED5_EN = 0, LED6_EN = 0,Led_play_mode = 0;
typedef struct
{
    u16 OnOffCount;
    u16 OnOffTimes;
    u16 CycleCount;
    u16 WaitTime;
    u16 LED_Step;
}MCLedDisplay;
MCLedDisplay    mcLedDisplay;
void KEY_LED_Display(void)
{
    if(FRSControl.CrossDownAcState==AC_ZERO_OFF)
		{
				LED1_EN = 0;
	      LED2_EN = 0;
	      LED3_EN = 0;
	      LED4_EN = 0;
	      LED5_EN = 0;
				LED6_EN = 0;
		
		}
		else if((!FRSControl.CrossDownAcState)&&(stru_Faults.B.TempOverError == 0)&&(TempOverFlagnoclean==0)&&(stru_Faults.R==0)&&(NTCOPENErrorFlag==0)&&(NTCSHORTErrorFlag==0))
    {
        if(AutoTemp==0)  //��������
				{
				    switch (TempGear)
            {
                case  0 : 
                  LED1_EN = 1;
									LED2_EN = 0;
									LED3_EN = 0;
									LED4_EN = 0;
									LED5_EN = 0;
									LED6_EN = 0;
//                    Ledflashcnt = 0;
                break;
        
                case  1 :  
                  LED1_EN = 0;
									LED2_EN = 1;
									LED3_EN = 0;
									LED4_EN = 0;
									LED5_EN = 0;
									LED6_EN = 0;
//                    Ledflashcnt = 0;
                break;
        
                case  2 : 
                  LED1_EN = 0;
									LED2_EN = 0;
									LED3_EN = 1;
									LED4_EN = 0;
									LED5_EN = 0;
									LED6_EN = 0;
//                    Ledflashcnt = 0;
                break;
                
            }
				}
				else  //����ѭ��
				{
				    LED1_EN = 0;
						LED2_EN = 0;
						LED3_EN = 0;
						LED4_EN = 1;
						LED5_EN = 1;
						LED6_EN = 0;
				}
    
      
//            if( (Cool_Lv) || (Overtmp_flag) || (OverVoltageflag) )    // �쳣������LED
//            {
//                LED4_EN = 0;
//                LED5_EN = 0;
//                LED6_EN = 0;
//            }
        
    }
    else // �й���
    {
        if(mcLedDisplay.LED_Step < 600)     // ��������֮ǰ��ȫ��LEDһ��ʱ��
        {
            LED1_EN = 0;
            LED2_EN = 0;
            LED3_EN = 0;
            LED4_EN = 0;
            LED5_EN = 0;
            LED6_EN = 0;
            mcLedDisplay.LED_Step++;
 
        }
        else
        {
  			 
					if((stru_Faults.B.VoltOverError)||(stru_Faults.B.VoltUnderError))
						LED_ONOFF_SET(2, 1);
					else if (stru_Faults.B.SoftCurretError)
						LED_ONOFF_SET(5, 1);
					else if (stru_Faults.B.HardCurretError)
						 LED_ONOFF_SET(4, 1);
          else if (stru_Faults.B.StartError) 
             LED_ONOFF_SET(3, 1); 
					else if (stru_Faults.B.PhaseLossError) 
             LED_ONOFF_SET(6, 1); 
          else if (stru_Faults.B.StallError) 
             LED_ONOFF_SET(1, 1);      
					else if (stru_Faults.B.TempOverError) 
             LED_ONOFF_SET(7, 1); 
          else if( (stru_Faults.B.NTCOPENError)||(stru_Faults.B.NTCSHORTError) )
             LED_ONOFF_SET(8, 1); 
          else if(stru_Faults.B.OffsetError) 
             LED_ONOFF_SET(9, 1); 
					else LED_ONOFF_SET(10, 1); 

                

         }
      }


    LED_1MS_CYCLE();
}

void LED_1MS_CYCLE(void)                 // 3��IO�ֱ����6��LED
{    
//	  GPIO_InitTypeDef GPIO_InitStruct;
//	  GPIO_StructInit(&GPIO_InitStruct);
//		GPIO_InitStruct.GPIO_Mode = GPIO_Mode_OUT;
//    GPIO_InitStruct.GPIO_PuPd = GPIO_PuPd_NOPULL;
//    GPIO_InitStruct.GPIO_Pin =   LED2_PIN;
//    GPIO_Init(LED2_PORT, &GPIO_InitStruct);
//				
//    /* P0.3 LED3  P0.1 LED2 */
//    GPIO_InitStruct.GPIO_Mode = GPIO_Mode_OUT;
//    GPIO_InitStruct.GPIO_PuPd = GPIO_PuPd_NOPULL;
//    GPIO_InitStruct.GPIO_Pin =  LED1_PIN ;
//    GPIO_Init(LED1_PORT, &GPIO_InitStruct);
//	
//	    
//		GPIO_InitStruct.GPIO_Mode = GPIO_Mode_IN;
//    GPIO_InitStruct.GPIO_PuPd = GPIO_PuPd_NOPULL;
//    GPIO_InitStruct.GPIO_Pin =  LED3_PIN;   
//	  GPIO_Init(LED3_PORT, &GPIO_InitStruct);
//	   LED1B_ON(); 
//		 LED2Y_OFF();
//	   LED3R_OFF();
	
    if(Led_play_mode > 5)
    {
        Led_play_mode = 0;
    }
    
			LED1B_OFF(); 
			LED2Y_OFF();
			LED3R_OFF();
			GPIO_InitTypeDef GPIO_InitStruct;
			GPIO_StructInit(&GPIO_InitStruct);
			
			GPIO_InitStruct.GPIO_Mode = GPIO_Mode_OUT;
			GPIO_InitStruct.GPIO_PuPd = GPIO_PuPd_NOPULL;
			GPIO_InitStruct.GPIO_Pin =   LED2_PIN;
			GPIO_Init(LED2_PORT, &GPIO_InitStruct);
					
			/* P0.3 LED3  P0.1 LED2 */
			GPIO_InitStruct.GPIO_Mode = GPIO_Mode_OUT;
			GPIO_InitStruct.GPIO_PuPd = GPIO_PuPd_NOPULL;
			GPIO_InitStruct.GPIO_Pin =  LED1_PIN | LED3_PIN;
			GPIO_Init(LED1_PORT, &GPIO_InitStruct);
			GPIO_Init(LED3_PORT, &GPIO_InitStruct);
			
			LED1B_OFF(); 
			LED2Y_OFF();
			LED3R_OFF();
		
    
    switch (Led_play_mode)
    {
        case 0:                            //��
        {
            if(LED1_EN)
            {
               GPIO_InitStruct.GPIO_Mode = GPIO_Mode_ANA;
							 GPIO_InitStruct.GPIO_PuPd = GPIO_PuPd_NOPULL;
							 GPIO_InitStruct.GPIO_Pin =   LED2_PIN;
							 GPIO_Init(LED2_PORT, &GPIO_InitStruct); 
						   LED1B_ON(); 
						   LED2Y_OFF();
						   LED3R_OFF();

            }
        }
        break;
        
        case 1:                            //��
        {
            if(LED2_EN)
            {
               /* P0.3 LED3  P0.1 LED2 */
							GPIO_InitStruct.GPIO_Mode = GPIO_Mode_IN;
							GPIO_InitStruct.GPIO_PuPd = GPIO_PuPd_NOPULL;
							GPIO_InitStruct.GPIO_Pin =  LED1_PIN ;
							GPIO_Init(LED1_PORT, &GPIO_InitStruct);
							LED1B_OFF(); 
							LED2Y_ON();
							LED3R_OFF();



            }
        }
        break;
        
        case 2:
        {            //��
            if(LED3_EN)
            {
          		GPIO_InitStruct.GPIO_Mode = GPIO_Mode_IN;
							GPIO_InitStruct.GPIO_PuPd = GPIO_PuPd_NOPULL;
							GPIO_InitStruct.GPIO_Pin =  LED1_PIN ;
							GPIO_Init(LED1_PORT, &GPIO_InitStruct);
							LED1B_OFF(); 
							LED2Y_OFF();
	            LED3R_ON();

            }
        }
        break;
              
        case 3:                            //���
        {
            if(LED4_EN)
            {
              GPIO_InitStruct.GPIO_Mode = GPIO_Mode_IN;
							GPIO_InitStruct.GPIO_PuPd = GPIO_PuPd_NOPULL;
							GPIO_InitStruct.GPIO_Pin =  LED3_PIN;   
							GPIO_Init(LED3_PORT, &GPIO_InitStruct);
							LED1B_OFF(); 
							LED2Y_ON();
							LED3R_OFF();

            }
        }
        break;
              
        case 4:                            //����
        {
            if(LED5_EN)
            {
              	GPIO_InitStruct.GPIO_Mode = GPIO_Mode_IN;
								GPIO_InitStruct.GPIO_PuPd = GPIO_PuPd_NOPULL;
								GPIO_InitStruct.GPIO_Pin =  LED3_PIN;   
								GPIO_Init(LED3_PORT, &GPIO_InitStruct);
								LED1B_ON(); 
								LED2Y_OFF();
								LED3R_OFF();

            }
        }
        break;
              
        case 5:                            //����D6
        {
            if(LED6_EN)
            {
              
               LED1B_OFF(); 
							 LED2Y_OFF();
							 LED3R_OFF();
            }
        }
        break;
    }
    
    Led_play_mode++;
}

void LED_ONOFF_SET(u8 ShineTimes, u8 ShineMode)
{
    mcLedDisplay.WaitTime = 1250;       // ��������֮��ĵȴ�ʱ�䣬��λ��ms
    
    if(mcLedDisplay.OnOffTimes < ShineTimes)
    {
        mcLedDisplay.OnOffCount++;
        if(mcLedDisplay.OnOffCount < 250)
        {
//            GP15 = 1;
//            GP16 = 1;
//            GP17 = 1;
//            LED1_EN = 1;
//            LED2_EN = 1;
//            LED3_EN = 1;
            
            if(ShineMode == 1)
            {
                LED1_EN = 1;
                LED5_EN = 1;
                LED6_EN = 1;
            }
        }
        else if(mcLedDisplay.OnOffCount < 500)
        {
//            GP15 = 0;
//            GP16 = 0;
//            GP17 = 0;
//            LED1_EN = 0;
//            LED2_EN = 0;
//            LED3_EN = 0;
            
            if(ShineMode == 1)
            {
                LED1_EN = 0;
                LED5_EN = 0;
                LED6_EN = 0;
            }
        }
        else
        {
            mcLedDisplay.OnOffCount=0;
            mcLedDisplay.OnOffTimes++;
        }
    }
    else
    {
        mcLedDisplay.CycleCount++;
        if(mcLedDisplay.CycleCount > mcLedDisplay.WaitTime)
        {
            mcLedDisplay.OnOffTimes=0;
            mcLedDisplay.CycleCount=0; 
        }
    }
}

void USER_APP_vTick1ms(void)
{
	Key_Refresh();  //���ٷ��°������ 
	RemtCmdAns();  //��λ�л����������е���
	HeaterControl_1ms(); //�����ź��Ƿ��������
	EraseWriteFlash();   //?????????
//	LED_Display();    //��IO�ص���
	KEY_LED_Display();  //3IO��6��
//	Alarm_light();
//	if((!FRSControl.CrossDownAcState)&&(stru_Faults.B.TempOverError == 0)&&(TempOverFlag==0))
//	{
//		PWMLED3();
//	}
	
}
extern s16 HeatTmp_real;
void USER_APP_vTick10ms(void)  //���ʼ��� ����ת�л�  ����˿NTC��� IPM NTC��� �ػ�����
{
	Get_Power();
	FunStateCharge();//����ת�л�  �л�ʱ����ɲ��
	
	UserSys.uiHeartNTCTem = GetHeartNTCTemp();
	FRSControl.HEATER_NTCTemperature = UserSys.uiHeartNTCTem;
	
	FRSControl.HEATER_NTCTemperaturereal =HeatTmp_real;
	FRSControl.IPM_OTPTemperature=GET_IPM_NTC_AD_VAL_RESULT;
	Shut_down();

}

void USER_APP_vTick05ms(void)
{


}

void zero_cheak(void)
{

}

void Shut_down()
{
 if(BrakeFlag==1)
 {
   LED1B_OFF();
	 LED2Y_OFF();
	 LED3R_OFF();
 }
}

/*******************************************************************************
 �������ƣ�    void SpecialGPIOInit(void)
 ����������    RST/SWDIO/SWCLK ������PIN�Ÿ��ó�ͨ��IO��ʼ��
 ���������    ��
 ���������    ��
 �� �� ֵ��    ��
 ����˵����
 �޸�����      �汾��          �޸���            �޸�����
 -----------------------------------------------------------------------------
 2022/01/28     V1.0           LLYY              ����
 *******************************************************************************/
void SpecialGPIOInit(void)
{
	  static u8 udelayGPIOcntdown=0;
	  static u8 IOstate=0;
	  static u8 u8SpecialIOinit=1;
	
    if(u8SpecialIOinit==1 && struFOC_CurrLoop.nBusVoltage>=2000)
		{
		  u8SpecialIOinit=0;
			GPIO_InitTypeDef GPIO_InitStruct;
			GPIO_StructInit(&GPIO_InitStruct);
					
			/* д�������� */	
			SYS_WR_PROTECT = 0x7a83;    
			
      /* change SWCKL AND SWDIO TO GPIO */
      SYS_IO_CFG &= (~BIT6);

//			GPIO_InitStruct.GPIO_Mode = GPIO_Mode_IN;
//			GPIO_InitStruct.GPIO_Pin =  key2_port_pin ;
//			GPIO_Init(key2_port, &GPIO_InitStruct);
//			GPIO_PinAFConfig(key1_port, GPIO_PinSource_9, AF0_GPIO);	
//			
//			GPIO_InitStruct.GPIO_Mode = GPIO_Mode_IN;
//			GPIO_InitStruct.GPIO_Pin =  key1_port_pin ;
//			GPIO_Init(key1_port, &GPIO_InitStruct);
//       	
//			GPIO_InitStruct.GPIO_Mode = GPIO_Mode_IN;
//			GPIO_InitStruct.GPIO_Pin =  key3_port_pin ;
//			GPIO_Init(key3_port, &GPIO_InitStruct);
//			GPIO_PinAFConfig(key1_port, GPIO_PinSource_8, AF0_GPIO);	
    }
		
    
		if(struFOC_CurrLoop.nBusVoltage<550)
		{
			udelayGPIOcntdown++;
		  if((udelayGPIOcntdown>50)&&(IOstate==0))
     	{
				IOstate =1;	 
				GPIO_InitTypeDef GPIO_InitStruct;
				GPIO_StructInit(&GPIO_InitStruct);
				
				SYS_WR_PROTECT = 0x7a83;
			
				/* Change  GPIO TO SWCKL AND SWDIO */								
				SYS_IO_CFG |= (BIT6);//
				
				/* P1.9 */
				GPIO_InitStruct.GPIO_Mode = GPIO_Mode_ANA;
				GPIO_InitStruct.GPIO_Pin = GPIO_Pin_9;
				GPIO_Init(GPIO1, &GPIO_InitStruct);		  							
        
				/* P1.8 */
				GPIO_InitStruct.GPIO_Mode = GPIO_Mode_ANA;
				GPIO_InitStruct.GPIO_Pin = GPIO_Pin_8;
				GPIO_Init(GPIO1, &GPIO_InitStruct);			
			}	
       			
		}

}
s16 uDCfil=3500;
s16 t_VdcSpdCoef;
s32 s32uDCfil=56000; 
void GetVdcSpeed(void)
{

				s32uDCfil+=(struFOC_CurrLoop.nVoltageCircleLim*16L-s32uDCfil)>>10;
				uDCfil = s32uDCfil>>4;
 
					if(uDCfil>=3300)
					{
						t_VdcSpdCoef = 1024;
					}
					else if(uDCfil>=(3300-500))
					{
		       t_VdcSpdCoef = 1024-((s32)(3300-uDCfil)*(1024-VDC_SPEED_REDUCTION_COEF)/500);
					}
					else
					{
						t_VdcSpdCoef = VDC_SPEED_REDUCTION_COEF;	
					}
			//t_VdcSpdCoef =1024;
			powerfreqcmd[0] = (u32)1024*App2CoreFreqTrans(User2AppFreqTrans(Gear_Speed_01))/1024;
			powerfreqcmd[1] = (u32)t_VdcSpdCoef*App2CoreFreqTrans(User2AppFreqTrans(Gear_Speed_02))/1024;
      powerfreqcmd[2] = (u32)t_VdcSpdCoef*App2CoreFreqTrans(User2AppFreqTrans(Gear_Speed_03))/1024;
		//	testspeed = (s32)t_VdcSpdCoef*App2CoreFreqTrans(User2AppFreqTrans(Gear_Speed_03))/1024;
}

#ifdef MemoryMode
void MemoryRestore(void)
{
	 // Memorymessag.cmd_exe =(remotor.add[2]&0x000ff00)>>8;
	  TempGear_memory =(remotor_memory&0x0000000f);

		if(TempGear_memory>3)
		{
				TempGear = 0;
		}
		else if(TempGear_memory == 3)
		{
				AutoTemp = 1;
		}
		else
		{
			TempGear = TempGear_memory;
		}

}

void vLoadForFlashing(void)
{
	if((AutoTemp==1)&&(TempGear_memory!=3))
	{
		TempGear_memory=3;
		Memorymsg =  TempGear_memory;
		Memorymessag_eraseflg =1;		//������־λ		
	}
	
	if((TempGear_memory!=TempGear)&&(AutoTemp==0))
	{			
			TempGear_memory=TempGear;
			Memorymsg =  TempGear_memory;
			Memorymessag_eraseflg =1;		//������־λ					
	}
}
#endif 
#if 1//def MemoryMode  lgh
void EraseWriteFlash(void)
{
//		if((Memorymessag_eraseflg==1)&&(Sys_State!=RUN))
	if((Memorymessag_eraseflg==1)&&(struFOC_CtrProc.bMC_RunFlg==0))
	{
			Memorymessag_eraseflg=0;
		 __disable_irq();
		EraseSector(Rmt_NVM_Sector_StartAddr, NVR_TYPE, 0x9A0D361F);
	  /* ң�������*ÿ�����ֽ��� */
		ProgramPage(Rmt_NVM_Sector_StartAddr, sizeof(Memorymsg), (u8 *)&Memorymsg, NVR_TYPE,0x9AFDA40C);
//		 Nvr_UserRoomErase(200);
//		Nvr_UserRoomWrite(200,Memorymsg);
		 __enable_irq();			
	} 
}
#endif 

void Get_Power(void)
{
	PowerCalc(&struFOC_CurrLoop.mStatCurrDQ, &struFOC_CurrLoop.mStatVoltDQ, &struPower);
}

void FunStateCharge(void)
{
	static uint16_t FunStateCnt = 0;
	
	if(UserSys.ucUserFunState == USERFUN_STATE_CLEAN)
	{
		FunStateCnt++;
		if(FunStateCnt > 1000)
		{
			FunStateCnt = 0;
			UserSys.ucUserFunState = USERFUN_STATE_WAIT;
			UserSys.cleanset =0;
			FunStateCnt=60;
		}
	}
	else if(UserSys.ucUserFunState == USERFUN_STATE_NORMAL)
	{
		if(UserSys.cleanset==1)
		{
			UserSys.ucUserFunState = USERFUN_STATE_WAIT;
			FunStateCnt=100;
		}
		
		if(UserSys.RunTime>RUN_TIME)
		{
			UserSys.ucUserFunState = USERFUN_STATE_WAIT;
			FunStateCnt=100;
		}
	}
	else if(UserSys.ucUserFunState == USERFUN_STATE_WAIT)
	{
		if(FunStateCnt>0)
		{
			FunStateCnt--;
		}
		else
		{
			if(UserSys.RunTime<RUN_TIME)
			{
				if(UserSys.cleanset==1)
				{
					UserSys.ucUserFunState = USERFUN_STATE_CLEAN;
				}
				else
				{
					UserSys.ucUserFunState = USERFUN_STATE_NORMAL;
				}	
			}			
		}
	}
	else if(UserSys.ucUserFunState == USERFUN_STATE_FAULT)
	{
		if(stru_Faults.R == 0)
		{
			UserSys.ucUserFunState = USERFUN_STATE_WAIT;	
		}	
	}
	
	 if(stru_Faults.R != 0)   //���ֹ��������FAULT״̬
     {
         UserSys.ucUserFunState = USERFUN_STATE_FAULT;
     }
	 
	if(UserSys.ucUserFunState == USERFUN_STATE_NORMAL)
	{
		UserSys.ucMotorDir = CW;
	}
	else if(UserSys.ucUserFunState == USERFUN_STATE_CLEAN)
	{
		UserSys.ucMotorDir = CCW;
	}
}
uint16_t GetHeartNTCTemp(void)
{

	volatile static s16 Temp_adc_get_temp;
	volatile static uint16_t Temp_adc_get;
	volatile static s16 Temp_adc2;
	volatile static uint8_t temp = 0;
	
	Temp_adc_get_temp = GET_HEART_NTC_AD_VAL_RESULT;
	if(Temp_adc_get_temp < 0)
		Temp_adc_get_temp = 0;
	
	Temp_adc_get = (Temp_adc_get_temp + (int32_t)Temp_adc_get) >> 1;
	if(Temp_adc_get > AD_TEMP_MAX_VAL)
		Temp_adc_get = AD_TEMP_MAX_VAL;
	
	return Temp_adc_get;

}

 u16 u16ledduty = 0;
 u16 u16ledcnt = 0;
 u16 u16time = 0;
 u8  red = 0;
 u8  flag = 0;
 void PWMLED4(u16 MaxDuty)
{
		
//    static u16 u16ledduty = 0;
//    static u16 u16ledcnt = 0;
//    static u16 u16time = 0;
//    static u8  red = 0;
//		static u8  flag = 0;
    if( u16time++ > 100 )  //200
    {
        u16time = 0;
			
        if( u16ledduty < MaxDuty && 0 == red )
        {
            u16ledduty++;
        }
        else
        {
            red  = 1;
        }
				
        if( u16ledduty > 0 && 1 == red )
        {
            u16ledduty--;
            if( u16ledduty == 0 )
            {
                if( flag < 5 )
                {
                    flag ++;
                    red  = 0;
                }
                else if( flag == 5 )
                {
                    flag = 0;
                    red  = 0;
                }
            }
        }
        else
        {
            red = 0;
        }
    }

    u16ledcnt ++;
    if( u16ledcnt >= MaxDuty ) u16ledcnt = 0;

    if(u16ledcnt <= (u16ledduty))  //���Duty
    {
        if( flag < 3 )
        {
					TempGear=0;
					LED1B_ON();
					LED2Y_OFF();
					LED3R_OFF();
        }
        else
        {
					TempGear=2;
					LED1B_OFF();
					LED2Y_OFF();
					LED3R_ON();
        }
    }
    else if(u16ledcnt > (u16ledduty))  //���Duty
    {
        LED1B_OFF();
				LED2Y_OFF();
				LED3R_OFF();		
    }
}

 void PWMLED3()
{
		
//    static u16 u16ledduty = 0;
//    static u16 u16ledcnt = 0;
//    static u16 u16time = 0;
//    static u8  red = 0;
//	static u8  flag = 0;
//    if( u16time++ > 100 )  //200
//    {
//        u16time = 0;
//			
//        if( u16ledduty < MaxDuty && 0 == red )
//        {
//            u16ledduty++;
//        }
//        else
//        {
//            red  = 1;
//        }
//				
//        if( u16ledduty > 0 && 1 == red )
//        {
//            u16ledduty--;
//            if( u16ledduty == 0 )
//            {
//                if( flag < 5 )
//                {
//                    flag ++;
//                    red  = 0;
//                }
//                else if( flag == 5 )
//                {
//                    flag = 0;
//                    red  = 0;
//                }
//            }
//        }
//        else
//        {
//            red = 0;
//        }
//    }

//    u16ledcnt ++;
//    if( u16ledcnt >= MaxDuty ) u16ledcnt = 0;

//    if(u16ledcnt <= (u16ledduty))  //���Duty
//    {
//        if( flag < 3 )
//        {
//			TempGear=0;
//       LED1B_ON();
//			LED2Y_OFF();
//			LED3R_OFF();
//        }
//        else
//        {
//			TempGear=1;
//      LED1B_OFF();
//			LED2Y_OFF();
//			LED3R_ON();
//        }
//    }
//    else if(u16ledcnt > (u16ledduty))  //���Duty
//    {
//        LED1B_OFF();
//		LED2Y_OFF();
//		LED3R_OFF();		
//    }

	 
   static u8 TempGear_old=0;
	 static u8 AutoTemp_old=0;
	 static u16 shinecnt=0;
	 if((stru_Faults.R==0)&&(TempOverFlag==0))
	{	
	if(AutoTemp_old==AutoTemp)
	{
	 if(AutoTemp==1)
		{	   
			shinecnt++;
			if(shinecnt>2000) 
				shinecnt=0;
		if(TempGear_old==TempGear)
		{
		  if(TempGear==0)
			{
//				if(shinecnt<=1000)
//				{
//					LED1B_ON();
//					LED2Y_OFF();
//					LED3R_OFF();
//				}
//				else 
//				{
//					LED1B_OFF();
//					LED2Y_OFF();
//					LED3R_OFF();
//				}
				PWM_blink(Rise);				
			}
			else if(TempGear==2)
			{
//				if(shinecnt<=1000)
//				{
//						LED1B_OFF();
//						LED2Y_OFF();
//						LED3R_ON();
//				}
//				else 
//				{
//					LED1B_OFF();
//					LED2Y_OFF();
//					LED3R_OFF();
//				}
				
		  PWM_blink(Fall);	
			}
		}
		else
		{ 

			led_duty=0;
			led_on_CNT=0;
			led_off_CNT=0;
			LED1B_OFF();
			LED2Y_OFF();
			LED3R_OFF();
			
		}
			
			TempGear_old=	TempGear;	
		}		
	 else 
	  {
		 if(TempGear_old==TempGear)
		 {
		  if(TempGear==0)
			{ 				
				LED1B_ON();
        LED2Y_OFF();
				LED3R_OFF();
			}
			else if(TempGear==1)
		  {	
				LED1B_OFF();
        LED2Y_ON();
				LED3R_OFF();		 
			}
			else
			{	
				LED1B_OFF();
        LED2Y_OFF();
				LED3R_ON();	

			}	
	  }
    else
		{ 
			led_on_CNT=0;
			led_off_CNT=0;

			LED1B_OFF();
			LED2Y_OFF();
			LED3R_OFF();
		}	
	 TempGear_old=TempGear;			
	}
}
else
{
	blink_OFF_CNT=0;
	blink_ON_CNT=0;	
	AutoTempLED2S=0;
	LED1B_OFF();
	LED2Y_OFF();
	LED3R_OFF();
}
AutoTemp_old=AutoTemp;

}
}
void PWM_blink(u8 COND)
{ 
if(COND==Rise)
{
 if(AutoTempLED2S<2800)
 {
   if(led_on_CNT<led_duty)
		{  
			led_on_CNT++;
			LED1B_ON();			
      LED3R_OFF(); 
		}	

		else
		{
		  if(led_off_CNT<(200-led_duty))
		 {
			 led_off_CNT++;
       LED3R_ON();	
			 LED1B_OFF();	
		 }
		 else
		 {
		  led_on_CNT=0;
			led_off_CNT=0;
			led_duty++; 
		 }
		}	
  }
 else
 {
   LED1B_ON();
	 LED3R_OFF();
 } 	
}
else
{	
 if(AutoTempLED2S<6200)
{
  if(led_on_CNT<led_duty)
		{  
			led_on_CNT++;
			LED1B_OFF();			
      LED3R_ON(); 
		}	
		else
		{
		  if(led_off_CNT<(210-led_duty))
		 {
			 led_off_CNT++;
       LED3R_OFF();	
			 LED1B_ON();	
		 }
		 else
		 {
		  led_on_CNT=0;
			led_off_CNT=0;
			led_duty++; 
		 }	 
		}
}
 else
 {
    LED1B_OFF();
	  LED3R_ON();
 }
}
}
u8 WaveCnt=0;
u8 WaveCnt1=0;
u8 WaveCnt2=0;
u8 delayfalg=0;
s8 TmpPwmdelta = 0;
extern u8 NTCorStaller;
s16 HEATER_NTCTemperatureold; //�ɼ�����˿ʵ���¶�ֵ
u8  HeatTmp_old = 0, HeatTmp_new = 0, HeatTmp_updowmLv = 0;               //0������    1���㶨    2���½�

#define HEATUP                      (0)           // ����˿�¶���������
#define HEATDOWN                    (1)           // ����˿�¶������½�
#define HEATHOLDON                  (2)           // ����˿�¶�û�б仯

u8 ThrowWaveBase_Swh_Flag=0;
u8 StallMode_Delay_Cnt=0;
void USER_APP_vTick500ms(void)
{

#ifdef FRS_WORKIN_ON_TEMP

	WaveCnt++;
	if(WaveCnt>=2)
	{
		WaveCnt=0;
		if(abs(FRSControl.TargetTemperature-FRSControl.HEATER_NTCTemperature)>2250)
		{
			WaveCnt1=4;
		}
		else if(abs(FRSControl.TargetTemperature-FRSControl.HEATER_NTCTemperature)>1250)
		{
			WaveCnt1=3;
		}
		else if(abs(FRSControl.TargetTemperature-FRSControl.HEATER_NTCTemperature)>750)
		{
			WaveCnt1=2;
		}
		else
		{
			WaveCnt1=1;
		}
		if(FRSControl.ThrowWaveBase_Old!=FRSControl.ThrowWaveBase)
		{
			FRSControl.StallMode =0;
			if(FRSControl.ThrowWaveBase_Old>FRSControl.ThrowWaveBase)
			{ThrowWaveBase_Swh_Flag=1;}
		}		
		FRSControl.ThrowWaveBase_Old = FRSControl.ThrowWaveBase;	
		if(FRSControl.HEATER_NTCTemperature < FRSControl.TargetTemperature)
		{			
				if((FRSControl.TargetTemperature- FRSControl.HEATER_NTCTemperature)>2000)
				{
					if(FRSControl.StallMode ==0)
					{
						FRSControl.ThrowWaveCnt = FRSControl.ThrowWaveLimitMax;
					}
					else
					{
//						if(FRSControl.HEATER_NTCTemperature<FRSControl.HEATER_NTCTemperature_Old)
//						{					

						 FRSControl.ThrowWaveCnt+=2;
//						}
//						else
//						{
//						 
//						}
					}
					FRSControl.temp_decre_Flag=0;
				}
				else 
				{  
					if(FRSControl.StallMode ==0)
				{	
						if(FRSControl.temp_incre_Flag==0)
						{			 
							FRSControl.ThrowWaveCnt+=WaveCnt1;	
							FRSControl.temp_incre_Flag=1;	
							FRSControl.temp_decre_Flag=0;
						}	
						else
						{
							if(++FRSControl.temp_incre_Cnt>4)
							{
	//						FRSControl.temp_incre_Flag=0;	
								FRSControl.temp_incre_Cnt=0;
								FRSControl.ThrowWaveCnt+=WaveCnt1;
							}		 
						}
						
					}
				}
				
				if(FRSControl.StallMode ==1)
				{
					if(iTargetGear==0)
					{ 
						if(TempGear==1)
						{
							 if(FRSControl.ThrowWaveCnt>=(FRSControl.ThrowWaveBase-4))
							{
							FRSControl.StallMode =0;	
							}
						}
						else if(TempGear==2)
						{
							if(FRSControl.ThrowWaveCnt>=(FRSControl.ThrowWaveBase-10))
							{
							FRSControl.StallMode =0;	
							}
						}				
					}
					else if(iTargetGear==1)
					{
						
							if(TempGear==1)
							{
								if(FRSControl.ThrowWaveCnt>=(FRSControl.ThrowWaveBase-7))
								{
								FRSControl.StallMode =0;	
								}
							}
							
							else if(TempGear==2)
							{
								if(FRSControl.ThrowWaveCnt>=(FRSControl.ThrowWaveBase-18))
								{
								FRSControl.StallMode =0;	
								}
							}
					}
				}
		}
	else if (FRSControl.HEATER_NTCTemperature > FRSControl.TargetTemperature)
	{  
			if(ThrowWaveBase_Swh_Flag==1)
			{
			StallMode_Delay_Cnt++;
				if(StallMode_Delay_Cnt>10)
				{
				 ThrowWaveBase_Swh_Flag=0;
				StallMode_Delay_Cnt=0;
				}
			}
		  else
			{
				if((FRSControl.HEATER_NTCTemperature-FRSControl.TargetTemperature)>2000)
				{
					if(FRSControl.StallMode ==0)
					{
						FRSControl.ThrowWaveCnt = 0;
						FRSControl.StallMode =1;			
					}
					FRSControl.temp_incre_Flag=0;
				}
				else
				{
					if(FRSControl.StallMode ==0)
					{
						if(FRSControl.temp_decre_Flag==0)
						{			 
							FRSControl.ThrowWaveCnt-=WaveCnt1;	
							FRSControl.temp_decre_Flag=1;	
							FRSControl.temp_incre_Flag=0;	
						}	
						else
						{
							if(++FRSControl.temp_decre_Cnt>3)
							{
		//				 FRSControl.temp_decre_Flag=0;	
							 FRSControl.temp_decre_Cnt=0;
							 FRSControl.ThrowWaveCnt-=WaveCnt1;
							}		 
						}	
				  }				
//				 else
//				 {
//					FRSControl.ThrowWaveCnt-=1;
//					if(FRSControl.ThrowWaveCnt<0)
//					{
//					FRSControl.ThrowWaveCnt=0;
//					}
//				 }	
			 }	
		}
	}			
		if(FRSControl.ThrowWaveCnt<0)
		{
			FRSControl.ThrowWaveCnt=0;						
		}
	 if(FRSControl.ThrowWaveCnt> FRSControl.ThrowWaveLimitMax)
		{
			FRSControl.ThrowWaveCnt=FRSControl.ThrowWaveLimitMax;
		}		
//	FRSControl.HEATER_NTCTemperature_Old = FRSControl.HEATER_NTCTemperature;
	}
//  	if(TempOverFlag==1)
//		{
//			TempGear=0;
//      FRSControl.ThrowWaveCnt	=0;		
//		  TempOver_nCheckCnt3++;
//			if(TempOver_nCheckCnt3>10)
//			{
//			TempOverFlag=0;
//			TempOver_nCheckCnt3=0;
//			PWMOutputs(MCPWM0, DISABLE);
//			stru_Faults.B.TempOverError = 1;//�¶ȹ��ϱ�־λ��1	
//			}
//		}
#endif	
}

////void USER_APP_vTick500ms(void)   //500ms������˿��������
////{/*
////#if (TEMP_CONSTANT_FUNCTION == FUNCTION_ON)
////	if(FRSControl.ucHeatFuncEnable == 1)   //����˿��������
////	{
////		 HeaterTemperature_Control();  //����˿�¶ȿ���
////	}
////#endif
////*/

////	if(FRS_WORKIN_ON_TEMP==TRUE)   //NTC AD���·�ʽ
////	{
////			if(FRSControl.CrossDownAcState==0)
////		{

////				
////	//			if((AutoTemp==0))//(iTargetGear==1)&&(TempGear ==2)&&  //ԭ�¿����������
////	//			{
////	//					FRSControl.ThrowWaveCnt = FRSControl.ThrowWaveLimitMax;
////	//				
////	//					if(++WaveCnt2>=4)
////	//					{
////	//						delayfalg=1;
////	//						WaveCnt2=0;
////	//						HEATER_NTCTemperatureold = FRSControl.HEATER_NTCTemperature;
////	//					}
////	//				
////	//					if((delayfalg==1)&&(FRSControl.HEATER_NTCTemperature<(HEATER_NTCTemperatureold-500)))
////	//					{
////	//						NTCorStaller=1;
////	//					}
////	//				
////	//			}	
////	//			else	
////				{	
////					delayfalg=0;
////					WaveCnt2=0;
////					HEATER_NTCTemperatureold = FRSControl.HEATER_NTCTemperature;
////					WaveCnt++;
////				if(WaveCnt>=2)
////				{
////					WaveCnt=0;
////					if(abs(FRSControl.TargetTemperature-FRSControl.HEATER_NTCTemperature)>2250)
////					{
////						WaveCnt1=4;
////					}
////					else if(abs(FRSControl.TargetTemperature-FRSControl.HEATER_NTCTemperature)>1250)
////					{
////						WaveCnt1=3;
////					}
////					else if(abs(FRSControl.TargetTemperature-FRSControl.HEATER_NTCTemperature)>750)
////					{
////						WaveCnt1=2;
////					}
////					else
////					{
////						WaveCnt1=1;
////					}
////					if(FRSControl.ThrowWaveBase_Old!=FRSControl.ThrowWaveBase)
////					{
////						FRSControl.StallMode =0;
////					}		
////					FRSControl.ThrowWaveBase_Old = FRSControl.ThrowWaveBase;	
////					if(FRSControl.HEATER_NTCTemperature < FRSControl.TargetTemperature)
////					{			
////							if((FRSControl.TargetTemperature- FRSControl.HEATER_NTCTemperature)>2000)
////							{
////								if(FRSControl.StallMode ==0)
////								{
////									FRSControl.ThrowWaveCnt = FRSControl.ThrowWaveLimitMax;
////								}
////								else
////								{
////									if(FRSControl.HEATER_NTCTemperature>FRSControl.HEATER_NTCTemperature_Old)
////									{					
////									}
////									else
////									{
////										FRSControl.ThrowWaveCnt+=1;
////									}
////								}
////								FRSControl.temp_decre_Flag=0;
////							}
////							else 
////							{  		
////									if(FRSControl.temp_incre_Flag==0)
////									{			 
////										FRSControl.ThrowWaveCnt+=WaveCnt1;	
////										FRSControl.temp_incre_Flag=1;	
////										FRSControl.temp_decre_Flag=0;
////									}	
////									else
////									{
////										if(++FRSControl.temp_incre_Cnt>4)
////										{
////				//						FRSControl.temp_incre_Flag=0;	
////											FRSControl.temp_incre_Cnt=0;
////											FRSControl.ThrowWaveCnt+=WaveCnt1;
////										}		 
////									}
////									if((FRSControl.StallMode ==1)&&(FRSControl.ThrowWaveCnt>=FRSControl.ThrowWaveBase-2))
////									{
////										FRSControl.StallMode =0;
////									}     		 
////							}
////					}
////					else if (FRSControl.HEATER_NTCTemperature > FRSControl.TargetTemperature)
////					{
////						
////						if((FRSControl.HEATER_NTCTemperature-FRSControl.TargetTemperature)>3000)
////						{
////							if(FRSControl.StallMode ==0)
////							{
////								FRSControl.ThrowWaveCnt = 0;
////								FRSControl.StallMode =1;			
////							}
////							else
////							{
////								FRSControl.ThrowWaveCnt -= 1;	
////							}
////							FRSControl.temp_incre_Flag=0;
////						}
////						else
////						{
////							if(FRSControl.temp_decre_Flag==0)
////							{			 
////								FRSControl.ThrowWaveCnt-=WaveCnt1;	
////								FRSControl.temp_decre_Flag=1;	
////								FRSControl.temp_incre_Flag=0;	
////							}	
////							else
////							{
////								if(++FRSControl.temp_decre_Cnt>3)
////								{
////			//				 FRSControl.temp_decre_Flag=0;	
////								 FRSControl.temp_decre_Cnt=0;
////								 FRSControl.ThrowWaveCnt-=WaveCnt1;
////								}		 
////							}				
////						}	
////					}
////					if(FRSControl.ThrowWaveCnt<0)
////					{
////						FRSControl.ThrowWaveCnt=0;						
////					}
////					else if(FRSControl.ThrowWaveCnt> FRSControl.ThrowWaveLimitMax)
////					{
////						FRSControl.ThrowWaveCnt=FRSControl.ThrowWaveLimitMax;
////					}		
////				FRSControl.HEATER_NTCTemperature_Old = FRSControl.HEATER_NTCTemperature;	
////				}
////			}
////		
////		}
////		else
////		{
////			HEATER_NTCTemperatureold=FRSControl.HEATER_NTCTemperature;
////			delayfalg=0;
////			WaveCnt2=0;
////		}
////		
////	
////	
////	}
////	else if(FRS_WORKIN_ON_TEMP==FALSE)   //NTC ���϶ȿ��·�ʽ
////	{

////			if(FRSControl.CrossDownAcState==0)
////		{
////					  HeatTmp_old = HeatTmp_new;
////            HeatTmp_new = HeatTmp_real;
////            if(HeatTmp_new > HeatTmp_old)       // ��ǰ�¶ȱ��ϴεͣ�����
////            {
////              HeatTmp_updowmLv = HEATUP;             //�¶�����
////            }
////            else if(HeatTmp_new < HeatTmp_old)  // ��ǰ�¶ȱ��ϴθߣ�����
////            {
////              HeatTmp_updowmLv = HEATDOWN;           //�¶��½�
////            }
////            else
////            {
////                HeatTmp_updowmLv = HEATHOLDON;       //����ģʽ
////            }
////           
////            if(HeatTmp_real < FRSControl.TargetTemperaturereal)         // ʵ���¶ȵ����趨�¶�ֵ
////            {
////              if(HeatTmp_updowmLv != HEATUP)         // �¶ȱ��ϴε�
////              {
////                if(FRSControl.TargetTemperaturereal - HeatTmp_real >= 12)
////                {
////                  TmpPwmdelta += 5;
////                }
////                else
////                {
////                  TmpPwmdelta++;
////                }
////              }
////            }
////            else if(HeatTmp_real > FRSControl.TargetTemperaturereal)
////            {
////              if(HeatTmp_updowmLv != HEATDOWN)
////              {
////                if(HeatTmp_real - FRSControl.TargetTemperaturereal >= 12)
////                {
////                  TmpPwmdelta -= 5;
////                }
////                else
////                {
////                  TmpPwmdelta--;
////                }
////              }
////            }          
////         
////						
////					FRSControl.ThrowWaveCnt = FRSControl.ThrowWaveBase + TmpPwmdelta ; 
////					if(FRSControl.ThrowWaveCnt<0)
////					{
////						FRSControl.ThrowWaveCnt=0;						
////					}
////					else if(FRSControl.ThrowWaveCnt> FRSControl.ThrowWaveLimitMax)
////					{
////						FRSControl.ThrowWaveCnt=FRSControl.ThrowWaveLimitMax;
////					}	

////						
////			
////		}
////		else
////		{
////			  FRSControl.ThrowWaveCnt=0;	
////		}

////	}


////	
////	
////	
////	
////	
////	
////	
////	
////	
////}



//void Alarm_light(void)
//{

//	switch(stru_Faults.R)
//	{
//		case(1):
//			LED_flashing_alarm(1);
//     break;		
//		case(2):
//			LED_flashing_alarm(2);
//		 break;	
//    case(4):			
//     LED_flashing_alarm(3);
//		 break;	
//      case(8):			
//     LED_flashing_alarm(4);
//			 break;	
//     case(16):			
//     LED_flashing_alarm(5);
//		  break;	
//     case(32):			
//     LED_flashing_alarm(6);
//		  break;	
//		 case(64):			
//     LED_flashing_alarm(7);
//		  break;
//		 case(128):
//		  LED_flashing_alarm(8);
//		  break;
//  }
//}


void LED_flashing_alarm(u16 Blink_cnt,u8 Light_num,u16 Interval)
{ 
//	LED_flashing_alarm(3,Red,400);	  //3�� һ��60*5ms=300ms�� 300ms�� ��1����˸���  ��ʱ400*5ms=2s ����ѭ����˸
	static u16 Light_ON_cnt=0;
	static u16 Light_OFF_cnt=0;
	static u16 Light_Interval_cnt=0;
	static u8 Light_Blink_cnt=0;

	
	if(Light_Blink_cnt<Blink_cnt)  
	{
			Light_ON_cnt++;
	if(Light_ON_cnt<60)
		{ 
			Light_Col_Contr(Light_num,On);	
    }
		else
		{
		   Light_OFF_cnt++;
			 Light_Col_Contr(Light_num,Off);	
		}	
		if(Light_OFF_cnt>60)
			{
			 Light_Blink_cnt++;
			 Light_ON_cnt=0;
			 Light_OFF_cnt=0;
			}	
	}		
	else 
	{	
	  	Light_Col_Contr(Red,Off);
			Light_Col_Contr(Yellow,Off);
		  Light_Col_Contr(Blue,Off);
			Light_Interval_cnt++;
		   if(Light_Interval_cnt>Interval)
			 {
			   Light_ON_cnt=0;
				 Light_OFF_cnt=0;
				 Light_Interval_cnt=0;
				 Light_Blink_cnt=0;
			 }
		}
}

void Light_Col_Contr(u8 Light_Col,u8 onfoff_state)
{
 if(onfoff_state==On)
 {
		if(Light_Col==Blue)
		{
		LED1B_ON();	 
		}
		else if(Light_Col==Yellow)
		{
		LED2Y_ON();
		} 
		else
		{
		LED3R_ON();
		}
 }
 else
 {
    if(Light_Col==Blue)
		{
		LED1B_OFF();	 
		}
		else if(Light_Col==Yellow)
		{
		LED2Y_OFF();
		} 
		else
		{
		LED3R_OFF();
		}
 }  
}

