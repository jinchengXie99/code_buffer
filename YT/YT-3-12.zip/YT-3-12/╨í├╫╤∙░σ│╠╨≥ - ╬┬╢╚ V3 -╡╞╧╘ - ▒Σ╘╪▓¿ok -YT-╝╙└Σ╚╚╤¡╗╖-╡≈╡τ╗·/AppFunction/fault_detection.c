/*******************************************************************************
 * 版权所有 (C)2019, LINKO SEMICONDUCTOR Co.ltd
 *
 * 文件名称： fault_detection.c
 * 文件标识：
 * 内容摘要： fault detectiong: volt ,current, temperature, stall, empty, phaseloss,\
 *
 * 其它说明： 无
 * 当前版本： V1.0
 * 作    者： andrew kong
 * 完成日期： 2019年11月28日
 *
 *******************************************************************************/
#include "fault_detection.h"
#include "MC_type.h"
#include "MC_parameter.h"
#include "Global_Variable.h"
#include "state_machine.h"
#include "FOC_Drive.h"
#include "USER_APP.h"
#include "PowerCalculation.h"
#include "HeatControl.h"

stru_CurrentAmplitude_t struCurrentAmplitude;    //缺相检测电流幅值结构体
stru_CurrPhaseUVW   struImaxCurrent;             //缺相检测相电流最大值结构体

stru_FaultVariable_t stru_FaultValue;
volatile stru_FaultStatus_t stru_Faults;

stru_FaultTime_t struFaultVoltTime;
stru_FaultTime_t struFaultEmptyTime;
stru_FaultTime_t struFaultBlockTime;
stru_FaultTime_t struFaultStallTime;
stru_FaultTime_t struFaultCurrentTime;
stru_FaultTime_t struFaultTempTime;
stru_FaultTime_t struFaultPhaseTime;
stru_FaultTime_t struFaultStartTime;
/*****************************************************************************
 * 函数名   : void FaultCurrentCheck(stru_CurrPhaseUVW *pstruCurrent,stru_FaultTime_t *pFaultTime)
 * 说明     : 软件过流检测
 * 设计思路 ：1. 如果三相电流绝对值超过设定的软件过流值，则判定为软件过流。
 * 参数     ：Ia、Ib、Ic
 * 返回值   ：无
 * 修改时间 ：2020.08.17
 *****************************************************************************/
volatile u16 SoftCur_Cnt=0;
void FaultCurrentCheck(INT16 cur,INT16 proThh)
{
   
 //if((ABS(pstruCurrent->nPhaseU) > stru_FaultValue.nOverCurrent) || (ABS(pstruCurrent->nPhaseV) > stru_FaultValue.nOverCurrent) || (ABS(pstruCurrent->nPhaseW) > stru_FaultValue.nOverCurrent))
	 if(cur>proThh)
    {
			  if(SoftCur_Cnt < 1)
				{
					  SoftCur_Cnt++;
				}
				else
				{
					SoftCur_Cnt=0;
            PWMOutputs(MCPWM0, DISABLE);
            stru_Faults.B.SoftCurretError = 1;
				}
    }
		else
		{
			  if(SoftCur_Cnt > 0)
				{
					  SoftCur_Cnt--;
				}
		}
}

/*****************************************************************************
 * 函数名   : void FaultVoltageCheck(s32 Udcb, stru_stru_FaultTime_t *FaultTime)
 * 说明     : 过欠压检测
 * 设计思路 ：1.当母线电压大于过压设定值则判定为过压故障;当母线电压小于欠压设定值 \
 *              则判定为欠压故障。滤波时间为1s，这个可根据实际需求修改。
 * 参数     ：Udcb，stru_stru_FaultTime_t
 * 返回值   ：无
 * 修改时间 ：2020.08.17
 *****************************************************************************/
void FaultVoltageCheck(s32 Udcb, stru_FaultTime_t *pFaultTime)
{
    if(Udcb >= stru_FaultValue.nOverVoltage)    //母线电压大于过压设定值则时间累加
    {
        pFaultTime->nCheckCnt1 ++;
    }
    else if(Udcb < stru_FaultValue.nUnderVoltage) // 母线电压小于欠压设定值则时间累加
    {
        pFaultTime->nCheckCnt2 ++;
    }
    else
    {
        pFaultTime->nCheckCnt1 = 0;
        pFaultTime->nCheckCnt2 = 0;
    }

    if(pFaultTime->nCheckCnt1 >= 100)//时间超过1s则判定为过压
    {
        PWMOutputs(MCPWM0, DISABLE);
        pFaultTime->nCheckCnt1 = 0;
        stru_Faults.B.VoltOverError = 1;//过压错误标志位置1
    }

    if(pFaultTime->nCheckCnt2 >= 100)//时间超过1s则判定为欠压
    {
        PWMOutputs(MCPWM0, DISABLE);
        pFaultTime->nCheckCnt2 = 0;
        stru_Faults.B.VoltUnderError = 1;//欠压错误标志位置1
    }
}


/*****************************************************************************
 * 函数名   : FaultEmptyCheck(s16 Iq, s32 wSpeedFbk, stru_stru_FaultTime_t *FaultTime)
 * 说明     : 离水空转检测
 * 设计思路 ：1.如果Iq小于空转电流设定值，并且转速大于空转转速设定值，则判定为离水空转。\
 *              滤波时间为1s，这个可根据实际需求修改。
 * 参数     ：s16 nIq, s32 wSpeedFbk, stru_FaultTime_t *pstruFaultTime
 * 返回值   ：无
 * 修改时间 ：2020.08.17
 *****************************************************************************/
void FaultEmptyCheck(s16 nIq, s32 wSpeedFbk, stru_FaultTime_t *pstruFaultTime)
{
    if((ABS(nIq) < stru_FaultValue.nEmptyCurrent) && (ABS(wSpeedFbk) > stru_FaultValue.wEmptySpeed)) //如果Iq小于设定值，转速大于设定值则时间累加，否则时间清0
    {
        pstruFaultTime->nCheckCnt1 ++;
    }
    else
    {
        pstruFaultTime->nCheckCnt1 = 0;
    }

    if(pstruFaultTime->nCheckCnt1 >= 200)  //累加时间超过200 * 5ms = 1s则判定为离水空转
    {
        PWMOutputs(MCPWM0, DISABLE);
        pstruFaultTime->nCheckCnt1 = 0;
        stru_Faults.B.EmptyError = 1;       //空转错误标志位置1
    }
}

/*****************************************************************************
 * 函数名   : FaultStallCheck(s32 SpeedFbk, s16 Iq, stru_CurrPhaseUVW *pIabcMax, stru_stru_FaultTime_t *FaultTime)
 * 说明     : 堵转检测
 * 设计思路 ：堵转检测目前分为三种办法
 *            1.电机转速大于设定最大值或者小于设定最小值，则判定为堵转 ;                 \
 *            2.Iq大于设定值，转速小于设定值则判断堵转。主要思路为电流和转速正相关;      \
 *            3.三相电流幅值大于堵转电流设定值则判断为堵转。
 * 参数     ：s32 nSpeedFbk, s16 bIq, stru_CurrPhaseUVW *pstruIabcMax, stru_FaultTime_t *pstruFaultTime
 * 返回值   ：无
 * 修改时间 ：2020.08.17
 *****************************************************************************/
void FaultStallCheck(s32 nSpeedFbk, s16 bIq, stru_CurrPhaseUVW *pstruIabcMax, stru_FaultTime_t *pstruFaultTime)
{
   if(pstruFaultTime->nStartDelay < 40) //延时5ms *40 = 200ms，避开开环拖动的影响
    {
        pstruFaultTime->nStartDelay ++;
    }
    else
    {
        if(ABS(nSpeedFbk) > stru_FaultValue.wStallSpeedMax)  //电机转速在实际运行范围之外则判定为堵转
        {
            if(pstruFaultTime->nCheckCnt1 < 10)      //滤波时间500ms 100*5ms
            {
                pstruFaultTime->nCheckCnt1 ++;
            }
            else                                 //判定为电机堵转
            {
				if(stru_FaultValue.RestallCnt < RESTART_CNT)
				{
					stru_FaultValue.RestallCnt++;
					PWMOutputs(MCPWM0, DISABLE);
					struFOC_CtrProc.eSysState = IDLE;
				}
				else
				{
					PWMOutputs(MCPWM0, DISABLE);
					pstruFaultTime->nCheckCnt1 = 0;
					stru_Faults.B.StallError = 1;         //堵转错误标志位置1
					stru_FaultValue.RestallCnt = 0;
				}
				stru_FaultValue.nStallFlag = 1;        //堵转标志位为1，用于区分触发了哪种堵转				
            }
        }
        else
        {
            pstruFaultTime->nCheckCnt1 = 0;
        }

        if((ABS(nSpeedFbk) < stru_FaultValue.wStallSpeed) && (ABS(bIq) > stru_FaultValue.nStallCurrentIq)) //Iq和转速不匹配，Iq大、转速低，则判定为堵转。
        {
            if(pstruFaultTime->nCheckCnt2 < 20)      //滤波时间2s，400*5ms = 2000ms
            {
                pstruFaultTime->nCheckCnt2 ++;
            }
            else                                 //判定为电机堵转
            {
                if(stru_FaultValue.RestallCnt < RESTART_CNT)
				{
					stru_FaultValue.RestallCnt++;
					PWMOutputs(MCPWM0, DISABLE);
					struFOC_CtrProc.eSysState = IDLE;
				}
				else
				{
					PWMOutputs(MCPWM0, DISABLE);
					pstruFaultTime->nCheckCnt2 = 0;
					stru_Faults.B.StallError = 1;         //堵转错误标志位置1
					stru_FaultValue.RestallCnt = 0;
				} 
				stru_FaultValue.nStallFlag = 2;        //堵转标志位为1，用于区分触发了哪种堵转  
            }
        }
        else
        {
            pstruFaultTime->nCheckCnt2 = 0;
        }

        if((pstruIabcMax->nPhaseU > stru_FaultValue.nStallCurrent) || (pstruIabcMax->nPhaseV > stru_FaultValue.nStallCurrent) || (pstruIabcMax->nPhaseW > stru_FaultValue.nStallCurrent))//三相电流幅值超过堵转电流设定值则判定为堵转
        {
           	if(stru_FaultValue.RestallCnt < RESTART_CNT)
            {
				stru_FaultValue.RestallCnt++;
				PWMOutputs(MCPWM0, DISABLE);
				struFOC_CtrProc.eSysState = IDLE;
			}
			else
			{
                PWMOutputs(MCPWM0, DISABLE);
                stru_Faults.B.StallError = 1;         //堵转错误标志位置1 
				stru_FaultValue.RestallCnt = 0;
			}  
			stru_FaultValue.nStallFlag = 3;        //堵转标志位为1，用于区分触发了哪种堵转
        }
				
		if((ABS(nSpeedFbk) > stru_FaultValue.wStallSpeedMax) && (ABS(bIq) < stru_FaultValue.nStallCurrentIq*2)) //Iq和转速不匹配，Iq大、转速低，则判定为堵转。
        {
            if(pstruFaultTime->nCheckCnt3 < 50)      //滤波时间2s，400*5ms = 2000ms
            {
                pstruFaultTime->nCheckCnt3 ++;
            }
            else                                 //判定为电机堵转
            {
                if(stru_FaultValue.RestallCnt < RESTART_CNT)
				{
					stru_FaultValue.RestallCnt++;
					PWMOutputs(MCPWM0, DISABLE);
					struFOC_CtrProc.eSysState = IDLE;
				}
				else
				{
					PWMOutputs(MCPWM0, DISABLE);
					pstruFaultTime->nCheckCnt3 = 0;
					stru_Faults.B.StallError = 1;         //堵转错误标志位置1
					stru_FaultValue.RestallCnt = 0;
				} 
				stru_FaultValue.nStallFlag = 4;        //堵转标志位为1，用于区分触发了哪种堵转  
            }
        }
        else
        {
            pstruFaultTime->nCheckCnt3 = 0;
        }				
    }
}
/*****************************************************************************
 * 函数名   : FaultBlockCheck(s32 nBusPower, stru_FaultTime_t *pstruFaultTime)
 * 说明     : 冷风堵孔检测
 * 设计思路 ：检测目前分为三种办法
 *            1.delta计算;                 \
 *            2.IPM最终限值     \
 *            3.冷风状态下，NTC温度升高。
 * 参数     ：
 * 返回值   ：无
 * 修改时间 ：
 *****************************************************************************/
s16 coldtimedelay=0;
s16 coldtimedelayflag=0;
s16 coldwinddelta=0;
s16 coldwindprotect=0;
s16 coldtimentcdelay=0;
s16 HEATER_NTCold=0;
s16 HEATER_NTCflag=0;
s16 protecttime=0;
void FaultBlockCheck(s32 nBusPower, stru_FaultTime_t *pstruFaultTime)
{
    if(pstruFaultTime->nStartDelay < 40) //延时5ms *40 = 200ms，避开开环拖动的影响
    {
        pstruFaultTime->nStartDelay ++;
    }
    else
    {
			//////////////////60s读冷风ipm数值////////////////////////
		   if(struFOC_CtrProc.bMC_RunFlg==1)//(TempGear==0)&&(AutoTemp==0)&&、、、、||((TempGear==0)&&((AutoTemp==0)))
			 {
			     coldtimedelay++;
			     if(((coldtimedelay>12000)&&(coldtimedelayflag==0))||((coldtimedelay>12000)&&((TempGear==0)&&(AutoTemp==0))))
					 {
						 coldtimedelayflag=1;
						 coldtimedelay=0;
						 if(iTargetGear==1) //高速
						 {
							 if(TempGear==2)
									FRSControl.IPM_OTPTemperature_OldHIGH=FRSControl.IPM_OTPTemperature-500;
							 else 
								 FRSControl.IPM_OTPTemperature_OldHIGH=FRSControl.IPM_OTPTemperature;
							 FRSControl.IPM_OTPTemperature_OldLOW=FRSControl.IPM_OTPTemperature-1000;
						 }
						 else //低速
						 {
						   if(TempGear==2)
									FRSControl.IPM_OTPTemperature_OldLOW=FRSControl.IPM_OTPTemperature-300;
							 else 
								 FRSControl.IPM_OTPTemperature_OldLOW=FRSControl.IPM_OTPTemperature;
						 FRSControl.IPM_OTPTemperature_OldHIGH=FRSControl.IPM_OTPTemperature+800;
						 }
					
					 }
					else 
					{
						if((coldtimedelayflag==0)&&((iTargetGear==1)))
						FRSControl.IPM_OTPTemperature_OldHIGH=10000;
						if((coldtimedelayflag==0)&&((iTargetGear==0)))
						FRSControl.IPM_OTPTemperature_OldLOW=9500;
					}
			 
			 }
			///////////////////冷风保护1---delta计算////////////////////
			
			 
			 if(iTargetGear==1)
			 {
					coldwinddelta=1500;
				 coldwindprotect=12000;
				 FRSControl.IPM_OTPTemperature_Old=FRSControl.IPM_OTPTemperature_OldHIGH;
			 } 		 
			 else 
			 {
					coldwinddelta=1500;
				  coldwindprotect=11000;
				 FRSControl.IPM_OTPTemperature_Old=FRSControl.IPM_OTPTemperature_OldLOW;
			 }
			 
		if(((FRSControl.IPM_OTPTemperature-FRSControl.IPM_OTPTemperature_Old)>coldwinddelta)&&(FRSControl.HEATER_NTCTemperature<NTCTempAD(70)))  //电机转速在实际运行范围之外则判定为堵转
        {
            if(pstruFaultTime->nCheckCnt1 < 400)      //滤波时间500ms 100*5ms
            {
                pstruFaultTime->nCheckCnt1 ++;
            }
            else                                 //判定为电机堵转
            {
                PWMOutputs(MCPWM0, DISABLE);
                pstruFaultTime->nCheckCnt1 = 0;
                stru_Faults.B.TempOverError = 1;         //堵转错误标志位置1
                stru_FaultValue.nStallFlag = 5;        //堵转标志位为1，用于区分触发了哪种堵转
            }
        }
        else
        {
					if(pstruFaultTime->nCheckCnt1>0)
					{
								pstruFaultTime->nCheckCnt1 --;
					}
        }

		
		
		
		///////////////////冷风保护2---IPM最终限值////////////////////
		if((FRSControl.IPM_OTPTemperature> coldwindprotect)&&(TempGear==0)&&(AutoTemp==0)&&(TempGear_Last!=2))
		{
		    if(pstruFaultTime->nIpmcnt1 < 400)      //滤波时间500ms 100*5ms
				{
						pstruFaultTime->nIpmcnt1 ++;
				}
				else                                 //判定为电机堵转
				{
					pstruFaultTime->nIpmcnt1=500;
					stru_Faults.B.TempOverError = 1;         //堵转错误标志位置1
          stru_FaultValue.nStallFlag = 6;        //堵转标志位为1，用于区分触发了哪种堵转
				}
		
		}
		else if(((FRSControl.IPM_OTPTemperature<= coldwindprotect))&&(stru_Faults.B.TempOverError  ==0))
		{
				pstruFaultTime->nIpmcnt1=0;
		}
		
	   ///////////////////冷风保护3---NTC温度升高////////////////////
		if((TempGear==0)&&(AutoTemp==0))
		{
		    coldtimentcdelay++;
			 if((coldtimentcdelay>3000))
				 {
					 HEATER_NTCold=FRSControl.HEATER_NTCTemperature; //采集发热丝实际温度值
					 coldtimentcdelay=0;
					 HEATER_NTCflag=1;
				 }
				 if(((FRSControl.HEATER_NTCTemperature-HEATER_NTCold)>100)&&(HEATER_NTCflag==1))
				 {
					    if(protecttime < 200)      //滤波时间500ms 100*5ms
							{
									protecttime ++;
							}
							else 
							{
							    protecttime=500;
								  stru_Faults.B.TempOverError = 1;         //堵转错误标志位置1
                  stru_FaultValue.nStallFlag = 7;        //堵转标志位为1，用于区分触发了哪种堵转
							}							       
				 }

		
		}
		else 
		{
				coldtimentcdelay=0;
				HEATER_NTCflag=0;
		}
			
		if(FRSControl.CrossDownAcState==1)
		{
//			pstruFaultTime->nIpmcnt2=0;
			coldtimentcdelay=0;
			HEATER_NTCflag=0;
		}			
		
		
		
    }
}
/*****************************************************************************
 * 函数名   : FaultSencondStartCheck(s32 wSpeedFbk, s16 nIq, stru_CurrPhaseUVW *pstruIabcMax, stru_FaultTime_t *pstruFaultTime)
 * 说明     : 二次启动
 * 设计思路 ：二次启动，在进入启动5s内判断，时间根据实际修改
 *          ：1.进入open之后2.5s内还没进入闭环，时间要根据实际情况修改                 \
 *          ：2.转速过高或者过低，设定阈值和堵转检测相同                             \
 *          : 3.三相电流幅值大于电流设定值，设定值和堵转检测相同
 * 参数     ：s32 wSpeedFbk, s16 nIq, stru_CurrPhaseUVW *pstruIabcMax, stru_FaultTime_t *pstruFaultTime
 * 返回值   ：无
 * 修改时间 ：2020.08.17
 *****************************************************************************/
void FaultStartCheck(s32 wSpeedFbk, s16 nIq, stru_CurrPhaseUVW *pstruIabcMax, stru_FaultTime_t *pstruFaultTime)
{
     if(g_FluxObsMode == 0) 
    {
        if(pstruFaultTime->nStartDelay < START_TIME_FAULT)
        {
            pstruFaultTime->nStartDelay ++;
        }
        else
        {
			if(stru_FaultValue.RestartCnt < RESTART_CNT)
			{
			stru_FaultValue.RestartCnt++;
			PWMOutputs(MCPWM0, DISABLE);
			struFOC_CtrProc.eSysState = IDLE;
			}
			else
			{
			PWMOutputs(MCPWM0, DISABLE);
			stru_Faults.B.StartError = 1;         //堵转错误标志位置1
			stru_FaultValue.nStartFlag = 1;        //堵转标志位为1，用于区分触发了哪种堵转
			stru_FaultValue.RestartCnt = 0;
			}  
        }

    }
    else
    {   
        pstruFaultTime->nStartDelay = 0;
    }
		
		
    if(struFOC_CtrProc.eSysState == RUN)
    {
        if(stru_FaultValue.StartCnt_5ms < 100)
        {
            stru_FaultValue.StartCnt_5ms++;
        }
    }
    if((stru_FaultValue.StartCnt_5ms == STARTUP_FAILED_TIME_5MS )&& (FRSControl.CrossDownAcState == 0))
    {
        if(struMotorSpeed.wSpeedfbk < 5000)
        {
            if(stru_FaultValue.RestartCnt < RESTART_CNT)
            {
                stru_FaultValue.RestartCnt++;
                PWMOutputs(MCPWM0, DISABLE);
                struFOC_CtrProc.eSysState = IDLE;
            }
            else
            {
                stru_Faults.B.StartError = 1;
				stru_FaultValue.nStartFlag = 2;
		        stru_FaultValue.RestartCnt = 0;
            }
        }
		else
		{
			stru_FaultValue.RestartCnt = 0;
		}
    }
        
}

/***********************************************************************************
 * 函数名   : FaultPhaseCheck(stru_CurrPhaseUVW  *pstruImaxCurrent,stru_CurrentAmplitude_t *pstruCurrentAmplitude, stru_FaultTime_t *pstruFaultTime)
 * 说明     : 缺相检测
 * 设计思路 ：1.三相电流幅值相差3倍，则判定为电机缺相，检测时间是2S，时间可以根据项目实际频率调整
 *            2.三相电流的积分值过小，持续1s，判定为缺相
 * 参数     ：stru_CurrPhaseUVW  *pstruImaxCurrent,stru_CurrentAmplitude_t *pstruCurrentAmplitude, stru_FaultTime_t *pstruFaultTime
 * 返回值   ：无
 * 修改时间 ：2020.08.17

 * 修改时间 : 2020.10.09
 * 修改内容 ：调整函数传参
 ***********************************************************************************/
void FaultPhaseCheck(stru_CurrPhaseUVW  *pstruImaxCurrent, stru_CurrentAmplitude_t *pstruCurrentAmplitude, stru_FaultTime_t *pstruFaultTime)
{
    if(pstruFaultTime->nCheckCnt1 < PHASE_CHCEK_TIME)//400*5ms
    {
        pstruFaultTime->nCheckCnt1 ++;
    }
    else
    {
        pstruFaultTime->nCheckCnt1 = 0;

        if(((pstruImaxCurrent->nPhaseU >> 2) > pstruImaxCurrent->nPhaseV) || (((pstruImaxCurrent->nPhaseV >> 2) > pstruImaxCurrent->nPhaseW)) ||
                (((pstruImaxCurrent->nPhaseW >> 2) > pstruImaxCurrent->nPhaseU)))            //如果三相电流幅值相差3倍则判定为缺相，倍数需要根据实际负载调整
        {
            PWMOutputs(MCPWM0, DISABLE);
            stru_Faults.B.PhaseLossError = 1;//缺相错误标志位置1
            stru_FaultValue.nPhaseLossFlag = 1;//第一种缺相保护
        }

        pstruImaxCurrent->nPhaseU = 0;
        pstruImaxCurrent->nPhaseV = 0;
        pstruImaxCurrent->nPhaseW = 0;
    }


}

/***********************************************************************************
 * 函数名   : FaultTempCheck(s16 nTemperature, stru_FaultTime_t *pFaultTime)
 * 说明     : 温度保护检测，针对NTC设计，对于PTC则需要修改
 * 设计思路 ：1.根据NTC的阻值去判断是否发生过温故障
 * 参数     ：s16 nTemperature, stru_FaultTime_t *pFaultTime
 * 返回值   ：无
 * 修改时间 ：2020.08.17
 ***********************************************************************************/

u16 TEMPOVER_LED_CNT=0;
u8 redLEDflag=0;
u16 TEMPOVER_LED_TIMECNT=0;
u16 TEMPOVER_LED_TIME=0;
u8 NTCorStaller=0;
u16 NTCorStallercnt=0;
//s16 sdajsldlas;
void FaultTempCheck(s16 nTemperature, stru_FaultTime_t *pstruFaultTime)
{




//发生冷风保护或温度过温 吹3s冷风后停机  依据客户要求定
		if((NTCorStaller==1)||(TempOverFlag ==1))
//		if((TempOverFlag ==1))
		{
			if(++NTCorStallercnt>=600)
			{
			 stru_Faults.B.TempOverError = 1;//温度故障标志位置1  超温设置
				NTCorStallercnt=2005;
			}
		 
		}
		

		
		
		
		/////////////////////////////NTC开路  可恢复且电机不停机 但是有灯显//////////////////////////////////////////////////////////
		if(NTCOPENErrorFlag==0)
		{
			if((nTemperature < TEMP_BREAK))    
			{
					pstruFaultTime->nCheckCnt3 ++;
			}
			else
			{
					pstruFaultTime->nCheckCnt3 = 0;
				  
			}
			if(pstruFaultTime->nCheckCnt3 > 100)//滤波时间2s，400*5ms = 2000ms
			{
//					PWMOutputs(MCPWM0, DISABLE);
	//        stru_Faults.B.NTCOPENError = 1;//温度故障标志位置1		
						NTCOPENErrorFlag = 1;        //NTC开路故障
					pstruFaultTime->nCheckCnt3 = 1001;
			}	
//		else	NTCOPENErrorFlag = 0;		
		}
    else 
		{
		  if((nTemperature >= TEMP_BREAK)&&((nTemperature <= TEMP_short)))    //可恢复 
			{
					NTCOPENErrorFlag = 0;
				pstruFaultTime->nCheckCnt3=0;
		  }
		}
		
	/////////////////////////////NTC短路  可恢复且电机不停机 但是有灯显 //////////////////////////////////////////////////////////	
   		if(NTCSHORTErrorFlag==0)
		{
			if((nTemperature > TEMP_short))    //
			{
					pstruFaultTime->nCheckCnt4 ++;
			}
			else
			{
					pstruFaultTime->nCheckCnt4 = 0;
				  
			}
			if(pstruFaultTime->nCheckCnt4 > 100)//滤波时间2s，400*5ms = 2000ms
			{
//					PWMOutputs(MCPWM0, DISABLE);
	//        stru_Faults.B.NTCOPENError = 1;//温度故障标志位置1		
						NTCSHORTErrorFlag = 1;    //NTC短路故障
					pstruFaultTime->nCheckCnt4 = 1001;
			}	
//		else	NTCOPENErrorFlag = 0;		
		}
    else 
		{
		  if((nTemperature >= TEMP_BREAK)&&((nTemperature <= TEMP_short)))    //NTC阻值小于设定值，则判定为过温故障;NTC阻值大于NTC开路值，则判定为NTC开路
			{
					NTCSHORTErrorFlag = 0;
				pstruFaultTime->nCheckCnt4=0;
		  }
		}
		

		
		
		
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////		 
		
		/////////////////////////////NTC过温吹3s冷风后停机  可恢复代码如下 //////////////////////////////////////////////////////////	

//    sdajsldlas=NTCTempAD(TEMP_OVER1);

		if(((nTemperature > NTCTempAD(TEMP_OVER1))&&(nTemperature < NTCTempAD(TEMP_FAULT)))&&(TempOverFlag==0))    //NTC阻值小于设定值，则判定为过温故障;NTC阻值大于NTC开路值，则判定为NTC开路
    {  
        pstruFaultTime->nCheckCnt6 ++;
    }
   else  pstruFaultTime->nCheckCnt6=0;
//	if(TempOverFlag==0)
//	{
		if(pstruFaultTime->nCheckCnt6 >=50)//滤波时间2s，400*5ms = 2000ms
		{
			pstruFaultTime->nCheckCnt6=205;
			TempGear_Last = TempGear;
//			TempGear=0;	
			TempOverFlag =1;
			TempOverFlagnoclean=1;
		}
//	
//	}

	//	if(TempOverFlag ==1)   //可恢复
//	{
//		if(nTemperature < NTCTempAD(TEMP_RECOVER1))   //过温可恢复
//			{					   
//				if(++pstruFaultTime->nCheckCnt5 >=1000 )//滤波时间2s，400*5ms = 2000ms
//				{
//					TempGear = TempGear_Last;
//					TempOverFlag = 0;
//					pstruFaultTime->nCheckCnt6=0;
//				}
//			}
//	}
//	else 
//	{
//		pstruFaultTime->nCheckCnt5=0;
	

		///////////////////////////////////NTC超温///////////////////////////////////////////
//    if((nTemperature > NTCTempAD(TEMP_FAULT))&&(nTemperature < TEMP_short1))    //NTC阻值小于设定值，则判定为过温故障;NTC阻值大于NTC开路值，则判定为NTC开路
//    {
//        pstruFaultTime->nCheckCnt1 ++;
//    }
//    else
//    {
//        pstruFaultTime->nCheckCnt1 = 0;
//    }
//	
//		    if(pstruFaultTime->nCheckCnt1 > 1000)//滤波时间2s，400*5ms = 2000ms
//    {
//        PWMOutputs(MCPWM0, DISABLE);
//			  NTCorStaller=1;
////        stru_Faults.B.TempOverError = 1;//温度故障标志位置1  超温设置
//        pstruFaultTime->nCheckCnt1 = 0;
//    }
		///////////////////////////////////NTC超温-温控器控制///////////////////////////////////////////
	
//	if((TempGear!=0)&&(FRSControl.ThrowWaveCnt==FRSControl.ThrowWaveLimitMax)&&(nTemperature < NTCTempAD(100)))    //NTC阻值小于设定值，则判定为过温故障;NTC阻值大于NTC开路值，则判定为NTC开路
//    {
//        pstruFaultTime->nCheckCnt2 ++;
//    }
//    else
//    {
//        pstruFaultTime->nCheckCnt2 = 0;
//    }

		
//		if((TempGear==2)&&(FRSControl.ThrowWaveCnt==FRSControl.ThrowWaveLimitMax)&&(nTemperature < NTCTempAD(220)))    //NTC阻值小于设定值，则判定为过温故障;NTC阻值大于NTC开路值，则判定为NTC开路
//    {
//        pstruFaultTime->nCheckCnt2 ++;
//    }
//    else
//    {
//        pstruFaultTime->nCheckCnt2 = 0;
//    }
		
		
		
		
		
//	if(pstruFaultTime->nCheckCnt2 >2000 )//滤波时间2s，400*5ms = 2000ms
//    {
////        PWMOutputs(MCPWM0, DISABLE);
//			  NTCorStaller=1;
////        stru_Faults.B.TempOverError = 1;//温度故障标志位置1  超温设置
//        pstruFaultTime->nCheckCnt2 = 0;
//    }
	
	
	
//	}	
}


/***********************************************************************************
 * 函数名   : FaultInit(void)
 * 说明     : 错误检测变量初始化
 * 设计思路 ：1.变量初始化
 * 参数     ：无
 * 返回值   ：无
 * 修改时间 ：2020.08.17
 ***********************************************************************************/
void FaultInit(void)
{
    /********过流故障检测变量初始化*****/
    stru_FaultValue.nOverCurrent = App2CoreCurTrans(User2AppCurTrans(I_PH_OVERCURRENT_FAULT));
    struFOC_CurrLoop.mStatCurrUVW.nPhaseU = 0;
    struFOC_CurrLoop.mStatCurrUVW.nPhaseV = 0;
    struFOC_CurrLoop.mStatCurrUVW.nPhaseW = 0;

    /******过欠压故障检测变量初始化*********/
    struFaultVoltTime.nCheckCnt1 = 0;
    struFaultVoltTime.nCheckCnt2 = 0;
	
    stru_FaultValue.nOverVoltage = User2AppVolTrans(U_DCB_OVERVOLTAGE_FAULT);
    stru_FaultValue.nUnderVoltage = User2AppVolTrans(U_DCB_UNDERVOLTAGE_FAULT);

    /******离水空转故障检测变量初始化********/
    struFaultEmptyTime.nCheckCnt1 = 0;
    stru_FaultValue.nEmptyCurrent = App2CoreCurTrans(User2AppCurTrans(I_PH_EMPTY_FAULT));

    /******堵转故障检测变量初始化*********/
    struFaultStallTime.nCheckCnt1 = 0;
    struFaultStallTime.nCheckCnt2 = 0;
	struFaultStallTime.nCheckCnt3 = 0;
    struFaultStallTime.nStartDelay = 0;
    stru_FaultValue.nStallCurrent = App2CoreCurTrans(User2AppCurTrans(I_PH_STALL_FAULT));
    stru_FaultValue.wStallSpeedMax = App2CoreFreqTrans(User2AppFreqTrans(SPEED_STALL_MAX_FAULT));
    stru_FaultValue.wStallSpeedMin = App2CoreFreqTrans(User2AppFreqTrans(SPEED_STALL_MIN_FAULT));
    stru_FaultValue.nStallCurrentIq = App2CoreCurTrans(User2AppCurTrans(IQ_STALL_FAULT));
    stru_FaultValue.wStallSpeed =  App2CoreFreqTrans(User2AppFreqTrans(SPEED_STALL_FAULT));
    stru_FaultValue.nStallFlag = 0;
	stru_FaultValue.nStallPower1 = STALL_POWER1;
	stru_FaultValue.nStallPower2 = STALL_POWER2;

    /******缺相故障检测变量初始化*********/
    struFaultPhaseTime.nCheckCnt1 = 0;

    struCurrentAmplitude.bFlag = 0;
    struCurrentAmplitude.nPhA = 0;
    struCurrentAmplitude.nPhB = 0;
    struCurrentAmplitude.nPhC = 0;
    struCurrentAmplitude.bTheta = 0;
    struCurrentAmplitude.wPhATemp = 0;
    struCurrentAmplitude.wPhBTemp = 0;
    struCurrentAmplitude.wPhCTemp = 0;

    struImaxCurrent.nPhaseU = 0;
    struImaxCurrent.nPhaseV = 0;
    struImaxCurrent.nPhaseW = 0;


    /*****温度故障检测变量初始化****/
    struFaultTempTime.nCheckCnt1 = 0;
    struFaultTempTime.nCheckCnt2=0;
		struFaultTempTime.nCheckCnt3=0;
		struFaultTempTime.nCheckCnt4=0;
		struFaultTempTime.nCheckCnt5=0;
		struFaultTempTime.nCheckCnt6=0;
		struFaultTempTime.nRecoverCntr=0;
		struFaultTempTime.nStartDelay=0;
		struFaultTempTime.nRecoverTime=0;
		struFaultTempTime.nIpmcnt1=0;
		struFaultTempTime.nIpmcnt2=0;

		
		
    /*启动故障检测变量初始化*/
    struFaultStartTime.nCheckCnt1 = 0;
    struFaultStartTime.nCheckCnt2 = 0;
    struFaultStartTime.nStartDelay = 0;
	stru_FaultValue.StartCnt_5ms=0;
	
}


/***********************************************************************************
 * 函数名   : FaultCheck(void)
 * 说明     : 故障检测处理
 * 设计思路 ：1.每个故障检测的处理周期为5ms
 * 参数     ：无
 * 返回值   ：无
 * 修改时间 ：2020.08.17
 ***********************************************************************************/
void FaultCheck(void)
{
    static s16 t_nFlagCheck = 0;

    if(t_nFlagCheck < 5)
    {
        t_nFlagCheck ++;
    }
    else
    {
        t_nFlagCheck = 1;
    }
    
		if(FRSControl.CrossDownAcState==1)	
		{
					LED1B_OFF();
        	LED2Y_OFF();
          LED3R_OFF();
		}

		

    switch(t_nFlagCheck)
    {
        case 1:
        {
			if(FRSControl.CrossDownAcState==0)						
			{
				FaultVoltageCheck(struFOC_CurrLoop.nBusVoltage, &struFaultVoltTime); //过欠压检测
//				stru_Faults.B.VoltUnderError=1;
//				stru_Faults.B.VoltOverError=1;
//				if(stru_Faults.B.VoltOverError == 1)
//				{
//					LED1B_OFF();
//        	LED2Y_OFF();
//          LED3R_OFF();					
//				  LED_flashing_alarm(3,Red,400);				
//				}
//				if(stru_Faults.B.VoltUnderError==1)
//				{
//					LED1B_OFF();
//        	LED2Y_OFF();
//          LED3R_OFF();
//				  LED_flashing_alarm(1,Red,400);	
//				}	
			}
                                                 
            break;
        }
        case 2:
        {
            if(struFOC_CtrProc.eSysState == RUN)
            {
				if(UserSys.ucUserFunState == USERFUN_STATE_NORMAL)
				{
//					FaultBlockCheck(struPower.wPowerValue, &struFaultBlockTime);  //堵冷风检测
					
				}
				
				FaultStallCheck(struMotorSpeed.wSpeedfbk, struFOC_CurrLoop.mStatCurrDQ.nAxisQ, &struImaxCurrent, &struFaultStallTime);  //堵转检测
            }
            break;
        }
        case 3:
        {
           FaultTempCheck(FRSControl.HEATER_NTCTemperature, &struFaultTempTime);                                             //过温检测
//					stru_Faults.B.TempOverError = 1;
//    	TempOverFlag=1;
	
//				if(FRSControl.CrossDownAcState==0)						
//				{
//			   if((stru_Faults.B.TempOverError == 1)||(NTCorStaller==1)||(TempOverFlag ==1))
//					{							
//					LED1B_OFF();
//        	LED2Y_OFF();
//          LED3R_OFF();					
//				  LED_flashing_alarm(10,Red,240);				
//					}
//					else if((TempOverFlag==1)||(TempOverFlagnoclean==1))
//					{
//				  LED1B_OFF();
//        	LED2Y_OFF();
//          LED3R_OFF();
//					LED_flashing_alarm(11,Red,240);					
//					}	
//					else if((stru_Faults.B.NTCSHORTError ==1)||(NTCSHORTErrorFlag==1))//温度故障标志位置1==1)
//					{
//				  LED1B_OFF();
//        	LED2Y_OFF();
//          LED3R_OFF();
//					LED_flashing_alarm(8,Red,400);					
//					}	
//					else if((stru_Faults.B.NTCOPENError == 1)||(NTCOPENErrorFlag==1))
//					{
//				  LED1B_OFF();
//        	LED2Y_OFF();
//          LED3R_OFF();
//					LED_flashing_alarm(9,Red,400);					
//					}	
//				}					
				
 			
							 
            break;
        }
        case 4:
        {
            if(struFOC_CtrProc.eSysState == RUN)
            {
                FaultPhaseCheck(&struImaxCurrent,&struCurrentAmplitude, &struFaultPhaseTime);                                    //缺相检测
            }
//						stru_Faults.B.PhaseLossError=1;
//						if(stru_Faults.B.PhaseLossError==1)
//							{						 
//					    LED1B_OFF();
//        	    LED2Y_OFF();
//              LED3R_OFF();					
//				      LED_flashing_alarm(6,Red,400);				
//							}				
            break;
        }
        case 5:
        {

            if(struFOC_CtrProc.eSysState == RUN)
            {
                 FaultStartCheck(struMotorSpeed.wSpeedfbk, struFOC_CurrLoop.mStatCurrDQ.nAxisQ, &struImaxCurrent, &struFaultStartTime);//二次启动检测
					
							
            }
//							  stru_Faults.B.StartError=1;
//							if(stru_Faults.B.StartError==1)
//							{
//							 
//					    LED1B_OFF();
//        	    LED2Y_OFF();
//              LED3R_OFF();					
//				      LED_flashing_alarm(5,Red,400);	
//							
//							}
//							if(stru_Faults.B.HardCurretError == 1)
//							{						 
//					    LED1B_OFF();
//        	    LED2Y_OFF();
//              LED3R_OFF();					
//				      LED_flashing_alarm(4,Red,400);				
//							}
//								if(stru_Faults.B.SoftCurretError==1)
//							{						 
//					    LED1B_OFF();
//        	    LED2Y_OFF();
//              LED3R_OFF();					
//				      LED_flashing_alarm(2,Red,400);				
//							}
            break;
        }
        default:
            break;
    }
}

/***********************************************************************************
 * 函数名   : FaultRecoverInit(void)
 * 说明     : 故障恢复变量初始化
 * 设计思路 ：变量初始化
 * 参数     ：无
 * 返回值   ：无
 * 修改时间 ：2020.08.17
 ***********************************************************************************/
void FaultRecoverInit(void)
{
    stru_Faults.R = 0;
    struFaultEmptyTime.nRecoverCntr   = 0;
    struFaultStallTime.nRecoverCntr   = 0;
    struFaultCurrentTime.nRecoverCntr = 0;
    struFaultCurrentTime.nRecoverTime = 0;
    struFaultVoltTime.nRecoverCntr    = 0;
    struFaultTempTime.nRecoverCntr    = 0;
    stru_FaultValue.nOverVoltageRecover = User2AppVolTrans(U_DCB_OVERVOLTAGE_RECOVER);
    stru_FaultValue.nUnderVoltageRecover = User2AppVolTrans(U_DCB_UNDERVOLTAGE_RECOVER);
}

/***********************************************************************************
 * 函数名   : FaultRecover(void)
 * 说明     : 故障恢复程序处理
 * 设计思路 ：1.过欠压恢复：       母线电压在正常工作范围内，持续2s则清除过欠压故障标志位; \
 *            2.软件&硬件过流恢复：2s后清除过流故障标志位;                                 \
 *            3.堵转恢复：         2s后清除堵转故障标志位;                                 \
 *            4.缺相恢复：         2s后清除过流故障标志位;                                 \
 *            5.过温恢复：         NTC在正常工作范围内，持续2s则清除过温故障标志位; \
 *            6.启动恢复：         1s后重启
 * 参数     ：无
 * 返回值   ：无
 * 修改时间 ：2020.08.17
 ***********************************************************************************/
void FaultRecover(void)
{
		if(FRSControl.CrossDownAcState==1)						
		    {
			     TempOverFlagnoclean=0;
					 TempOverFlag=0;
					 NTCorStaller=0;
				 	NTCorStallercnt=0;
					coldtimentcdelay=0;
					HEATER_NTCflag=0;
					protecttime=0;
					
		    }
	
    /****************过欠压恢复****************/
    if((stru_Faults.B.VoltOverError == 1) || (stru_Faults.B.VoltUnderError == 1))
    {
        //母线电压在欠压恢复值和过压恢复值之间则判定为正常状态
        if((struFOC_CurrLoop.nBusVoltage >= stru_FaultValue.nUnderVoltageRecover)
                && (struFOC_CurrLoop.nBusVoltage <= stru_FaultValue.nOverVoltageRecover))
        {
            if(struFaultVoltTime.nRecoverCntr < VOLT_FAULT_RECOVER_TIME)     //滤波时间2s，然后清零过欠压故障标志位
            {
                struFaultVoltTime.nRecoverCntr ++;
            }
            else
            {
                stru_Faults.B.VoltOverError = 0;
                stru_Faults.B.VoltUnderError = 0;
                struFaultVoltTime.nRecoverCntr = 0;
            }
        }
        else
        {
            struFaultVoltTime.nRecoverCntr = 0;
        }
				if(FRSControl.CrossDownAcState==1)						
		    {
			     stru_Faults.B.VoltOverError = 0;
					 stru_Faults.B.VoltUnderError = 0;
		    }
    }

    /****************过流恢复****************/
    if((stru_Faults.B.HardCurretError == 1) || (stru_Faults.B.SoftCurretError == 1))
   {
//        if(struFaultCurrentTime.nRecoverCntr < CURRENT_FAULT_RECOVER_TIME)//2s后清零过流故障标志位
//        {
//            struFaultCurrentTime.nRecoverCntr ++;
//        }
//        else
//        {
//            if(stru_Faults.B.HardCurretError == 1)
//            {
//                stru_Faults.B.HardCurretError = 0;
//            }

//            if(stru_Faults.B.SoftCurretError == 1)
//            {
//                stru_Faults.B.SoftCurretError = 0;
//            }

//            struFaultCurrentTime.nRecoverTime ++;
//            struFaultCurrentTime.nRecoverCntr = 0;
//        }
				if(FRSControl.CrossDownAcState==1)						
		    {
			     stru_Faults.B.HardCurretError = 0;
					 stru_Faults.B.SoftCurretError = 0;
		    }
    }

    /****************堵转恢复****************/
    if(stru_Faults.B.StallError == 1)
    {
////        if(struFaultStallTime.nRecoverCntr < STALL_FAULT_RECOVER_TIME)   //2s后清零堵转故障标志位
////        {
////            struFaultStallTime.nRecoverCntr ++;
////        }
////        else
////        {
////            stru_Faults.B.StallError = 0;
////            struFaultStallTime.nRecoverCntr = 0;
////            stru_FaultValue.nStallFlag = 0;
////        }
//		if(FRSControl.CrossDownAcState==1)						
//		{
//			stru_Faults.B.StallError = 0;
//		}
       if(FRSControl.CrossDownAcState==1)						
		    {
			     stru_Faults.B.StallError = 0;
		    }

    }

    /****************离水空转恢复****************/
//    if(stru_Faults.B.EmptyError == 1)
//    {
//        if(struFaultEmptyTime.nRecoverCntr < EMPTY_FAULT_RECOVER_TIME)//2s后清零离水空转故障标志位
//        {
//            struFaultEmptyTime.nRecoverCntr ++;
//        }
//        else
//        {
//            stru_Faults.B.EmptyError = 0;
//            struFaultEmptyTime.nRecoverCntr = 0;
//        }
//    }

    /****************缺相恢复****************/
    if(stru_Faults.B.PhaseLossError == 1)
    {
//        if(struFaultPhaseTime.nRecoverCntr < PHASELOSS_FAULT_RECOVER_TIME) //2s后清零缺相故障标志位
//        {
//            struFaultPhaseTime.nRecoverCntr ++;
//        }
//        else
//        {
//            stru_Faults.B.PhaseLossError = 0;
//            struFaultPhaseTime.nRecoverCntr = 0;
//        }
		if(FRSControl.CrossDownAcState==1)						
		{
			stru_Faults.B.PhaseLossError = 0;
		}
    }

    /****************过温恢复****************/
    if(stru_Faults.B.TempOverError == 1)   //超温断电恢复
    {
//        if((FRSControl.HEATER_NTCTemperature > TEMP_BREAK) && (FRSControl.HEATER_NTCTemperature < NTCTempAD(TEMP_RECOVER)))//NTC阻值在设定阻值之间则判定为正常状态
//        {
//            if(struFaultTempTime.nRecoverCntr < TEMP_FAULT_RECOVER_TIME)//滤波时间2s，然后清零过温故障标志位
//            {
//                struFaultTempTime.nRecoverCntr ++;
//            }
//            else
//            {
//                stru_Faults.B.TempOverError = 0;
//                struFaultTempTime.nRecoverCntr = 0;
//            }
//        }
//        else
//        {
//            struFaultTempTime.nRecoverCntr = 0;
//        }
				if(FRSControl.CrossDownAcState==1)						
				{
					stru_Faults.B.TempOverError = 0;
					
				}
    }

    /****************启动失败恢复****************/
    if(stru_Faults.B.StartError == 1)
    {
//        if(struFaultStartTime.nRecoverCntr < START_FAULT_RECOVER_TIME) //1s后清零缺相故障标志位
//        {
//            struFaultStartTime.nRecoverCntr ++;
//        }
//        else
//        {
//            stru_Faults.B.StartError = 0;
//            struFaultStartTime.nRecoverCntr = 0;
//            stru_FaultValue.nStartFlag = 0;
//        }
		if(FRSControl.CrossDownAcState==1)						
		{
			stru_Faults.B.StartError = 0;
		}
    }
		
		
		 if((stru_Faults.B.NTCOPENError == 1)||(stru_Faults.B.NTCSHORTError == 1))
    {
//        if(struFaultStartTime.nRecoverCntr < START_FAULT_RECOVER_TIME) //1s后清零缺相故障标志位
//        {
//            struFaultStartTime.nRecoverCntr ++;
//        }
//        else
//        {
//            stru_Faults.B.StartError = 0;
//            struFaultStartTime.nRecoverCntr = 0;
//            stru_FaultValue.nStartFlag = 0;
//        }
				if(FRSControl.CrossDownAcState==1)						
				{
					stru_Faults.B.NTCOPENError = 0;
					stru_Faults.B.NTCSHORTError = 0;
					
				}
    }
		
		
		
		

}

/***********************************************************************************
 * 函数名   : CurrentAmplitudeCalc(stru_CurrPhaseUVW *pstruCurrPhaseUVW,stru_SWLIBS_3wSyst *pCurrentAmplitude )
 * 说明     : 电流有效值计算，
 * 设计思路 ：半个电流周期内对电流积分
 * 参数     ：stru_CurrPhaseUVW *pstruCurrPhaseUVW, stru_SWLIBS_3wSyst *pCurrentAmplitude
 * 返回值   ：无
 * 修改时间 ：2020.10.9
 ***********************************************************************************/
void CurrentAmplitudeCalc(stru_CurrPhaseUVW *pstruCurrPhaseUVW, stru_CurrentAmplitude_t *pstruCurrentAmplitude, stru_CurrPhaseUVW *pstruCurrentMAX)
{
    //  if((pstruCurrentAmplitude->bTheta > 0) && (pstruCurrentAmplitude->bTheta < 32768))    //0° < Theta < 180°
    //  {
    //    if(pstruCurrentAmplitude->bFlag == 0)
    //    {
    //      pstruCurrentAmplitude->bFlag = 1;
    //      pstruCurrentAmplitude->wPhATemp = 0;
    //      pstruCurrentAmplitude->wPhBTemp = 0;
    //      pstruCurrentAmplitude->wPhCTemp = 0;
    //    }

    //    pstruCurrentAmplitude->wPhATemp = pstruCurrentAmplitude->wPhATemp + ABS(pstruCurrPhaseUVW->nPhaseU);
    //    pstruCurrentAmplitude->wPhBTemp = pstruCurrentAmplitude->wPhBTemp + ABS(pstruCurrPhaseUVW->nPhaseV);
    //    pstruCurrentAmplitude->wPhCTemp = pstruCurrentAmplitude->wPhCTemp + ABS(pstruCurrPhaseUVW->nPhaseW);

    //    pstruCurrentAmplitude->wPhATemp = sat(pstruCurrentAmplitude->wPhATemp,0x0000000F,0xFFFFFFF0); //数字量超出范围，则不再累加
    //    pstruCurrentAmplitude->wPhBTemp = sat(pstruCurrentAmplitude->wPhBTemp,0x0000000F,0xFFFFFFF0); //数字量超出范围，则不再累加
    //    pstruCurrentAmplitude->wPhCTemp = sat(pstruCurrentAmplitude->wPhCTemp,0x0000000F,0xFFFFFFF0); //数字量超出范围，则不再累加
    //  }
    //  else
    //  {
    //    pstruCurrentAmplitude->bFlag = 0;
    //    pstruCurrentAmplitude->nPhA = pstruCurrentAmplitude->wPhATemp * struCore2App.cur >> struCore2App.curShftNum;
    //    pstruCurrentAmplitude->nPhB = pstruCurrentAmplitude->wPhBTemp * struCore2App.cur >> struCore2App.curShftNum;
    //    pstruCurrentAmplitude->nPhC = pstruCurrentAmplitude->wPhCTemp * struCore2App.cur >> struCore2App.curShftNum;
    //  }


    /***********取三相电流最大值，缺相检测里面会用到************/
    if(ABS(pstruCurrPhaseUVW->nPhaseU) > pstruCurrentMAX->nPhaseU)
    {
        pstruCurrentMAX->nPhaseU = ABS(pstruCurrPhaseUVW->nPhaseU);
    }

    if(ABS(pstruCurrPhaseUVW->nPhaseV) > pstruCurrentMAX->nPhaseV)
    {
        pstruCurrentMAX->nPhaseV = ABS(pstruCurrPhaseUVW->nPhaseV);
    }

    if(ABS(pstruCurrPhaseUVW->nPhaseW) > pstruCurrentMAX->nPhaseW)
    {
        pstruCurrentMAX->nPhaseW = ABS(pstruCurrPhaseUVW->nPhaseW);
    }
}



